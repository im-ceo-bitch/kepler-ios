import AuthenticationServices
import SwiftUI
import UserNotifications
import UIKit
import CoreImage
import CoreImage.CIFilterBuiltins
import PassKit

private enum IumrahGuestAccountMode: String, CaseIterable, Identifiable {
    case register
    case signIn
    var id: String { rawValue }
}

private enum IumrahGuestAuthMethod: String, CaseIterable, Identifiable {
    case sms
    case email
    var id: String { rawValue }
}

private enum IumrahAccountTripScope: String, CaseIterable, Identifiable {
    case active
    case past
    var id: String { rawValue }
}

private enum IumrahFieldIssueTone {
    case warning
    case error

    var color: Color {
        switch self {
        case .warning: return .orange
        case .error: return .red
        }
    }
}

private struct IumrahFieldIssue {
    let message: String
    let tone: IumrahFieldIssueTone
}

struct IumrahAccountView: View {
    @EnvironmentObject private var account: IumrahAccountStore
    @EnvironmentObject private var bookings: BookingStore
    @EnvironmentObject private var settings: AppSettingsStore
    @EnvironmentObject private var chrome: AppChromeStore
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.iumrahTabIsActive) private var activeTab
    @AppStorage("iumrah.autoPageHelp") private var automaticPageHelp = true
    @State private var identityLinkOwner: String?
    @State private var identityLinkDate: Date?
    @ObservedObject private var clientNotifications = ClientNotificationCenter.shared
    @ObservedObject private var push = PushNotificationManager.shared

    @AppStorage(IumrahReferralLink.codeKey) private var pendingReferralCode = ""
    @AppStorage(IumrahReferralLink.consentKey) private var referralConsent = false
    @State private var guestAccountMode: IumrahGuestAccountMode = .signIn
    @State private var guestAuthMethod: IumrahGuestAuthMethod = .sms
    @State private var loginID = ""
    @State private var loginEmail = ""
    @State private var loginPhone = "+998"
    @State private var loginSMSCode = ""
    @State private var loginSMSChallengeID = ""
    @State private var loginPassword = ""
    @State private var loginEmailServerIssue: IumrahFieldIssue?
    @State private var registrationFirstName = ""
    @State private var registrationLastName = ""
    @State private var registrationEmail = ""
    @State private var registrationEmailCode = ""
    @State private var registrationEmailIssue: IumrahFieldIssue?
    @State private var loginEmailChallengeID = ""
    @State private var loginEmailCode = ""
    @State private var registrationEmailChallengeID = ""
    @State private var registrationPhone = "+998"
    @State private var registrationSMSCode = ""
    @State private var registrationSMSChallengeID = ""
    @State private var registrationPassword = ""
    @State private var registrationPasswordConfirm = ""
    @State private var isRegistering = false
    @State private var showSignOutConfirmation = false
    @State private var isLoggingIn = false
    @State private var loginError: String?
    @State private var appleNonce = ""
    @State private var isAppleSigningIn = false
    @State private var isGoogleSigningIn = false

    @State private var firstName = ""
    @State private var lastName = ""
    @State private var phone = ""
    @State private var email = ""
    @State private var telegram = ""
    @State private var whatsapp = ""
    @State private var isSavingProfile = false
    @State private var profileMessage: String?
    @State private var profileLoadedForID: String?
    @State private var notificationStatus: UNAuthorizationStatus = .notDetermined
    @State private var showProfileEditor = false
    @State private var identityCardFlipped = false
    @State private var showIdentityFullscreen = false
    @State private var showLanguageSheet = false
    @State private var showIdentityUnlockSheet = false
    @State private var identityRevealProgress: CGFloat = 0
    @State private var loginScrollNonce = 0
    @State private var walletPass: PKPass?
    @State private var showWalletPassSheet = false
    @State private var isLoadingWalletPass = false
    @State private var walletAlertMessage: String?
    @State private var identityPublicURL: String?
    @State private var identityCopyMessage: String?
    @State private var balanceRefreshRevision = 0
    @State private var tripScope: IumrahAccountTripScope = .active

    var body: some View {
        ScrollViewReader { proxy in
            IumrahRootScrollingPage(onRefresh: { await refreshAccountContent() }, helpContext: account.account == nil ? "account.guest" : "account.signed_in", fixedRefreshHeader: true, header: {
                accountHeader
            }, content: {
                LazyVStack(spacing: 20) {

                    if let profile = account.account {
                        IumrahAccountBalanceEntry(language: settings.language, refreshRevision: balanceRefreshRevision)
                        IumrahAccountFriendsEntry(language: settings.language)
                        automaticHelpCard
                        IumrahAccountRewardsCarousel(language: settings.language) {
                            IumrahAccountIdentityHeroCard(
                                profile: profile,
                                language: settings.language,
                                publicIdentityURL: (identityLinkOwner == account.bearerToken ? identityPublicURL : nil) ?? fallbackIdentityURL(profile.iumrahID),
                                copyMessage: identityCopyMessage,
                                onCopy: { copyIdentityID(profile) }
                            )
                        }
                        travelCompanionsEntryCard
                        walletSection(profile)

                        if let active = activeTrip {
                            IumrahTripWalletEntry(session: active, profile: profile, language: settings.language)
                        }
                        IumrahAccountSavedHotelsEntry(language: settings.language)
                        tripsSection
                        telegramIntegrationSection
                        paymentSecuritySection
                        servicesSection
                        settingsSection
                        signOutButton
                    } else {
                        seamlessGuestProfile
                        automaticHelpCard
                        IumrahBookingAccessCard(bookingID: nil)
                        guestSettingsSection
                    }
                }
                .padding(.horizontal, IumrahDesign.pagePadding)
                .padding(.top, 12)
                .padding(.bottom, 46)
                .frame(maxWidth: .infinity, alignment: .topLeading)
            })
            .onChange(of: guestAccountMode) { _, _ in
                loginError = nil
                loginEmailServerIssue = nil
                resetPhoneLoginState()
                resetPhoneRegistrationState()
                registrationEmailChallengeID = ""
                registrationEmailCode = ""
                registrationEmailIssue = nil
            }
            .onChange(of: loginScrollNonce) { _, _ in
                withAnimation(.spring(response: 0.55, dampingFraction: 0.90)) {
                    proxy.scrollTo("account-login", anchor: .top)
                }
            }
        }
        .background(Color.iumrahPageBackground.ignoresSafeArea(edges: .bottom))
        .modifier(IumrahPrimaryTabScrollChrome())
        .modifier(IumrahPerformanceHost())
        .task(id: activeTab) {
            guard activeTab else { return }
            loadProfileDraftIfNeeded(force: false)
            prepareIdentityRevealIfNeeded(account.iumrahID)
            await refreshNotificationStatus()
            // RootView owns trip restoration, push registration and synchronization.
            // Opening Account must not repeat that work.
            await refreshPublicIdentityLink()
        }
        .onChange(of: account.iumrahID) { oldValue, newValue in
            loadProfileDraftIfNeeded(force: true)
            if oldValue != newValue {
                prepareIdentityRevealIfNeeded(newValue, force: newValue != nil && oldValue != newValue)
                Task { await refreshPublicIdentityLink() }
            }
        }
        .sheet(isPresented: $showProfileEditor) {
            profileEditorSheet
        }
        .fullScreenCover(isPresented: $showLanguageSheet) {
            NavigationStack { IumrahLanguageSelectionSheet(currentLanguage: settings.language) }
                .environmentObject(settings)
        }
        .sheet(isPresented: $showIdentityUnlockSheet) {
            IumrahIdentityUnlockSheet(language: settings.language) {
                loginScrollNonce += 1
            }
        }
        .sheet(isPresented: $showWalletPassSheet) {
            if let walletPass {
                IumrahAddPassesView(pass: walletPass, isPresented: $showWalletPassSheet)
                    .ignoresSafeArea()
            }
        }
        .fullScreenCover(isPresented: $showIdentityFullscreen) {
            identityFullscreenView
        }
        .alert("Apple Wallet", isPresented: Binding(
            get: { walletAlertMessage != nil },
            set: { if !$0 { walletAlertMessage = nil } }
        )) {
            Button(tr("OK", "OK", "OK", "OK"), role: .cancel) {
                walletAlertMessage = nil
            }
        } message: {
            Text(walletAlertMessage ?? "")
        }
        .sheet(isPresented: $showSignOutConfirmation) {
            IumrahActionConfirmationSheet(
                title: tr("Sign out of iumrah?", "Выйти из iumrah?", "iumrah akkauntidan chiqasizmi?", "iumrah аккаунтидан чиқасизми?"),
                message: tr(
                    "Your trips stay safely linked to your iumrah account. You will need to sign in again on this device.",
                    "Ваши поездки останутся безопасно привязаны к аккаунту iumrah. На этом устройстве потребуется войти снова.",
                    "Safarlaringiz iumrah akkauntingizga xavfsiz bog‘langan holda qoladi. Bu qurilmada qayta kirishingiz kerak bo‘ladi.",
                    "Сафарларингиз iumrah аккаунтингизга хавфсиз боғланган ҳолда қолади. Бу қурилмада қайта киришингиз керак бўлади."
                ),
                confirmTitle: tr("Sign out", "Выйти", "Chiqish", "Чиқиш"),
                cancelTitle: tr("Cancel", "Отмена", "Bekor qilish", "Бекор қилиш"),
                confirmColor: .red
            ) {
                Task {
                    bookings.setAccountToken(nil)
                    await account.logout()
                    IumrahHaptics.soft()
                }
            }
        }
    }

    private var accountHeader: some View {
        IumrahPrimaryTabHeader(
            title: tr("Profile", "Профиль", "Profil", "Профиль"),
            footer: account.account.map { profile in
                AnyView(userDataEntryCard(profile).padding(.horizontal, IumrahDesign.pagePadding))
            },
            flexibleFooter: account.account != nil,
            animateMap: false
        )
    }

    private var seamlessGuestProfile: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 14) {
                Image(systemName: "person.crop.circle.fill").font(.system(size: 48)).foregroundStyle(.primary)
                VStack(alignment: .leading, spacing: 4) {
                    Text(bookings.sessions.first?.travelerName ?? tr("Welcome to iumrah", "Добро пожаловать в iumrah", "iumrah’ga xush kelibsiz", "iumrah’га хуш келибсиз"))
                        .font(.title3.weight(.bold))
                    if let id = bookings.sessions.first?.displayPilgrimID {
                        Text("iumrah ID " + id).font(.subheadline.monospacedDigit()).foregroundStyle(.secondary)
                    } else {
                        Text(tr("Your profile appears with your first booking.", "Ваш профиль появится после первого бронирования.", "Profilingiz birinchi brondan keyin paydo bo‘ladi.", "Профилингиз биринчи брондан кейин пайдо бўлади.")).font(.subheadline).foregroundStyle(.secondary)
                    }
                }
            }
            Button { chrome.navigate(to: .booking) } label: {
                HStack {
                    Image(systemName: "ticket")
                    Text(tr("My bookings", "Мои бронирования", "Bronlarim", "Бронларим"))
                    Spacer()
                    Image(systemName: "chevron.right").font(.caption.weight(.semibold))
                }.font(.headline)
            }.buttonStyle(.plain)
        }.frame(maxWidth: .infinity, alignment: .leading).iumrahCard()
    }

    private var automaticHelpCard: some View {
        Toggle(isOn: $automaticPageHelp) {
            HStack(spacing: 12) {
                Image(systemName: "questionmark.bubble.fill")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.primary)
                    .frame(width: 44, height: 44)
                    .iumrahGlass(in: Circle(), allowsStaticGlass: true)
                VStack(alignment: .leading, spacing: 4) {
                    Text(tr("Automatic tips", "Автоматические подсказки", "Avtomatik maslahatlar", "Автоматик маслаҳатлар")).font(.headline)
                    Text(tr("Show guidance when opening a page", "Показывать советы при открытии страниц", "Sahifa ochilganda maslahatlar", "Саҳифа очилганда маслаҳатлар")).font(.caption).foregroundStyle(.secondary)
                }
            }
        }
        .toggleStyle(.switch)
        .tint(.green)
        .iumrahCard()
    }

    private func identityCard(_ profile: IumrahAccountProfile) -> some View {
        VStack(spacing: 12) {
            ZStack {
                identityFront(profile)
                    .opacity(identityCardFlipped ? 0 : 1)

                identityBack(profile)
                    .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                    .opacity(identityCardFlipped ? 1 : 0)
            }
            .frame(height: 226)
            .overlay {
                IumrahIdentitySealOverlay(
                    progress: identityRevealProgress,
                    showsPrompt: false,
                    language: settings.language
                )
            }
            .rotation3DEffect(.degrees(identityCardFlipped ? 180 : 0), axis: (x: 0, y: 1, z: 0), perspective: 0.72)
            .animation(.spring(response: 0.52, dampingFraction: 0.82), value: identityCardFlipped)
            .contentShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
            .onTapGesture {
                IumrahHaptics.selection()
                identityCardFlipped.toggle()
            }

            HStack(spacing: 8) {
                if let identityCopyMessage {
                    Label(identityCopyMessage, systemImage: "checkmark.circle.fill")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.green)
                } else {
                    Label(
                        identityCardFlipped ? tr("Front side", "Лицевая сторона", "Old tomoni", "Олд томони") : tr("Tap to flip", "Нажмите, чтобы перевернуть", "Aylantirish uchun bosing", "Айлантириш учун босинг"),
                        systemImage: identityCardFlipped ? "rectangle.portrait.rotate" : "hand.tap.fill"
                    )
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                }
                Spacer()
                Button {
                    IumrahHaptics.selection()
                    showIdentityFullscreen = true
                } label: {
                    Label(tr("Full screen", "На весь экран", "To‘liq ekran", "Тўлиқ экран"), systemImage: "arrow.up.left.and.arrow.down.right")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.primary)
                        .padding(.horizontal, 12)
                        .frame(height: 36)
                        .iumrahGlass(in: Capsule(), interactive: true)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 6)
        }
    }

    private func identityFront(_ profile: IumrahAccountProfile) -> some View {
        let fullName = displayName(profile).split(separator: " ", maxSplits: 1, omittingEmptySubsequences: true)
        let first = fullName.first.map(String.init) ?? profile.firstName
        let last = fullName.dropFirst().first.map(String.init) ?? profile.lastName
        return ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .fill(Color.white)

            LinearGradient(
                colors: [Color.black.opacity(0.05), .clear, Color.black.opacity(0.02)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))

            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("iumrah ID")
                            .font(.system(size: 28, weight: .bold, design: .rounded))
                            .foregroundStyle(.black)
                        Text(tr("PERMANENT PILGRIM ACCOUNT", "ПОСТОЯННЫЙ АККАУНТ ПАЛОМНИКА", "DOIMIY ZIYORATCHI AKKAUNTI", "ДОИМИЙ ЗИЁРАТЧИ АККАУНТИ"))
                            .font(.system(size: 9, weight: .bold))
                            .tracking(1.4)
                            .foregroundStyle(.black.opacity(0.45))
                    }
                    Spacer()
                    Image(systemName: "wave.3.right")
                        .font(.system(size: 25, weight: .semibold))
                        .foregroundStyle(.black.opacity(0.42))
                }

                VStack(alignment: .leading, spacing: 12) {
                    identityFact(title: tr("First name", "Имя", "Ism", "Исм"), value: nonBlank(first) ?? nonBlank(profile.firstName) ?? tr("Pilgrim", "Паломник", "Ziyoratchi", "Зиёратчи"))
                    identityFact(title: tr("Last name", "Фамилия", "Familiya", "Фамилия"), value: nonBlank(last) ?? nonBlank(profile.lastName) ?? "—")
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("UMR ID")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.black.opacity(0.48))
                    HStack(alignment: .center, spacing: 12) {
                        Text(normalizedID(profile.iumrahID))
                            .font(.system(size: 28, weight: .bold, design: .monospaced))
                            .foregroundStyle(.black)
                            .tracking(1.6)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        Spacer(minLength: 8)
                        Button {
                            copyIdentityID(profile)
                        } label: {
                            Label(tr("Copy", "Копировать", "Nusxalash", "Нусхалаш"), systemImage: "doc.on.doc")
                                .font(.caption.weight(.bold))
                                .foregroundStyle(.black)
                                .padding(.horizontal, 12)
                                .frame(height: 34)
                                .background(Color.black.opacity(0.06), in: Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(22)
        }
        .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .strokeBorder(Color.black.opacity(0.07), lineWidth: 1)
        }
        .shadow(color: .black.opacity(0.08), radius: 22, y: 12)
    }

    private func identityBack(_ profile: IumrahAccountProfile) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .fill(Color.white)

            LinearGradient(
                colors: [Color.black.opacity(0.05), .clear, Color.black.opacity(0.02)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))

            HStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("iumrah ID")
                        .font(.system(size: 26, weight: .bold, design: .rounded))
                        .foregroundStyle(.black)
                    Text(tr("Digital pilgrim identity", "Цифровая ID-карта паломника", "Raqamli ziyoratchi ID", "Рақамли зиёратчи ID"))
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.black.opacity(0.54))
                    Spacer(minLength: 6)
                    Text("UMR ID")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.black.opacity(0.45))
                    Text(normalizedID(profile.iumrahID))
                        .font(.system(size: 22, weight: .bold, design: .monospaced))
                        .foregroundStyle(.black)
                    Text("iumrah.app")
                        .font(.caption.monospaced().weight(.semibold))
                        .foregroundStyle(.black.opacity(0.48))
                }

                Spacer(minLength: 6)

                qrCodeView(identityPublicURL ?? fallbackIdentityURL(profile.iumrahID), size: 116)
                    .padding(10)
                    .background(Color.white, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .strokeBorder(Color.black.opacity(0.08), lineWidth: 0.8)
                    }
            }
            .padding(22)
        }
        .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .strokeBorder(Color.black.opacity(0.07), lineWidth: 1)
        }
        .shadow(color: .black.opacity(0.08), radius: 22, y: 12)
    }

    private var identityFullscreenView: some View {
        ZStack {
            Rectangle()
                .fill(colorScheme == .dark ? Color.black.opacity(0.52) : Color.white.opacity(0.52))
                .background(.ultraThinMaterial)
                .ignoresSafeArea()
            if let profile = account.account {
                VStack(spacing: 22) {
                    HStack {
                        if !identityCardFlipped {
                            Button {
                                copyIdentityID(profile)
                            } label: {
                                Label(tr("Copy ID", "Скопировать ID", "ID ni nusxalash", "ID ни нусхалаш"), systemImage: "doc.on.doc")
                                    .font(.system(size: 14, weight: .semibold))
                                    .padding(.horizontal, 14)
                                    .frame(height: 44)
                                    .iumrahGlass(in: Capsule(), interactive: true, tint: colorScheme == .dark ? .white.opacity(0.12) : .white.opacity(0.58), chrome: true)
                            }
                            .buttonStyle(.plain)
                        }
                        Spacer()
                        IumrahGlassIconButton(systemName: "xmark", size: 46,
                            accessibilityLabel: tr("Close", "Закрыть", "Yopish", "Ёпиш")) {
                            showIdentityFullscreen = false
                        }
                    }

                    Spacer()

                    ZStack {
                        identityFront(profile).opacity(identityCardFlipped ? 0 : 1)
                        identityBack(profile)
                            .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                            .opacity(identityCardFlipped ? 1 : 0)
                    }
                    .frame(height: 248)
                    .rotation3DEffect(.degrees(identityCardFlipped ? 180 : 0), axis: (x: 0, y: 1, z: 0), perspective: 0.72)
                    .animation(.spring(response: 0.52, dampingFraction: 0.82), value: identityCardFlipped)
                    .onTapGesture {
                        IumrahHaptics.selection()
                        identityCardFlipped.toggle()
                    }

                    Text(identityCopyMessage ?? tr("Tap the card to flip it", "Нажмите на карту, чтобы перевернуть", "Kartani aylantirish uchun bosing", "Картани айлантириш учун босинг"))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle((identityCopyMessage == nil ? Color.secondary : Color.green).opacity(0.9))

                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
            }
        }
    }

    private func identityFact(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption.weight(.bold))
                .foregroundStyle(.black.opacity(0.46))
            Text(value)
                .font(.system(size: 21, weight: .bold, design: .rounded))
                .foregroundStyle(.black)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
        }
    }

    @ViewBuilder
    private func qrCodeView(_ value: String, size: CGFloat) -> some View {
        if let image = makeQRCode(value) {
            Image(uiImage: image)
                .interpolation(.none)
                .resizable()
                .scaledToFit()
                .frame(width: size, height: size)
        } else {
            Image(systemName: "qrcode")
                .font(.system(size: size * 0.66, weight: .medium))
                .frame(width: size, height: size)
                .foregroundStyle(.black)
        }
    }

    private func makeQRCode(_ value: String) -> UIImage? {
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(value.utf8)
        filter.correctionLevel = "M"
        guard let output = filter.outputImage else { return nil }
        let scaled = output.transformed(by: CGAffineTransform(scaleX: 10, y: 10))
        let context = CIContext(options: nil)
        guard let cg = context.createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cg)
    }

    private func walletSection(_ profile: IumrahAccountProfile) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(Color.black)
                        .frame(width: 48, height: 48)
                    Image(systemName: "wallet.pass.fill")
                        .font(.system(size: 19, weight: .semibold))
                        .foregroundStyle(.white)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text(tr("iumrah ID in Apple Wallet", "iumrah ID в Apple Wallet", "iumrah ID Apple Wallet’da", "iumrah ID Apple Wallet’да"))
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                    Text(tr(
                        "Keep your digital pilgrim ID and QR code available from Wallet.",
                        "Храните цифровую ID-карту паломника и QR-код прямо в Wallet.",
                        "Raqamli ziyoratchi ID va QR-kodni Wallet’da saqlang.",
                        "Рақамли зиёратчи ID ва QR-кодни Wallet’да сақланг."
                    ))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                }

                Spacer(minLength: 0)
            }

            if isLoadingWalletPass {
                HStack(spacing: 10) {
                    ProgressView()
                        .tint(.white)
                    Text(tr("Preparing Wallet", "Подготавливаем Wallet", "Wallet tayyorlanmoqda", "Wallet тайёрланмоқда"))
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, minHeight: 52)
                .background(Color.black, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            } else if PKPassLibrary.isPassLibraryAvailable() {
                Button {
                    Task { await addIdentityToWallet() }
                } label: {
                    HStack(spacing: 9) {
                        Image(systemName: "apple.logo")
                            .font(.system(size: 19, weight: .semibold))
                        Text("Wallet")
                            .font(.system(size: 17, weight: .semibold, design: .rounded))
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 15))
                .controlSize(.large)
                .tint(.black)
            } else {
                HStack(spacing: 9) {
                    Image(systemName: "apple.logo")
                    Text(tr("Wallet unavailable", "Wallet недоступен", "Wallet mavjud emas", "Wallet мавжуд эмас"))
                }
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, minHeight: 52)
                .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            }
        }
        .iumrahCard()
    }

    private func activeTripCard(_ session: StoredBookingSession) -> some View {
        Button { chrome.openBooking(id: session.id) } label: {
            VStack(alignment: .leading, spacing: 16) {
                HStack(alignment: .top, spacing: 12) {
                    IumrahIconBadge(
                        systemName: session.effectiveStatus.uppercased() == "IN_TRIP" ? "location.fill" : "airplane.departure",
                        role: session.effectiveStatus.uppercased() == "IN_TRIP" ? .location : .travel,
                        size: 48,
                        symbolSize: 19,
                        cornerRadius: 16
                    )

                    VStack(alignment: .leading, spacing: 4) {
                        Text(tr("Active trip", "Активная поездка", "Faol safar", "Фаол сафар"))
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.secondary)
                        Text("\(session.booking.route.originCode) → \(session.booking.route.outboundDestination)")
                            .font(.system(size: 23, weight: .bold, design: .rounded))
                        Text(L10n.format("booking_number_short", settings.language, session.displayBookingNumber))
                            .font(.caption.monospaced().weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 8)
                    Image(systemName: "chevron.right")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.tertiary)
                        .padding(.top, 16)
                }

                HStack(spacing: 8) {
                    statusChip(session.effectiveStatus)
                    tripDateChip(session)
                }

                if !session.booking.hotelNames.makkah.isEmpty {
                    Label(session.booking.hotelNames.makkah, systemImage: "building.2.fill")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .iumrahCard()
        }
        .buttonStyle(.plain)
    }

    private var tripsSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            NavigationLink {
                IumrahTripsHistoryView(
                    sessions: allTrips,
                    initialScopePast: tripScope == .past
                )
            } label: {
                HStack(alignment: .center, spacing: 12) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(tr("My trips", "Мои поездки", "Safarlarim", "Сафарларим"))
                            .font(.system(size: 25, weight: .bold, design: .rounded))
                            .foregroundStyle(.primary)
                        Text(tr("Current and previous journeys", "Активные и прошлые поездки", "Faol va oldingi safarlar", "Фаол ва олдинги сафарлар"))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 8)
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.tertiary)
                        .frame(width: 34, height: 34)
                        .iumrahGlass(in: Circle(), interactive: false, chrome: true)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Picker("", selection: $tripScope) {
                Text(tr("Active", "Активные", "Faol", "Фаол")).tag(IumrahAccountTripScope.active)
                Text(tr("Past", "Прошлые", "Oldingi", "Олдинги")).tag(IumrahAccountTripScope.past)
            }
            .pickerStyle(.segmented)
            .onChange(of: tripScope) { _, _ in IumrahHaptics.selection() }

            if scopedAccountTrips.isEmpty {
                HStack(spacing: 12) {
                    IumrahIconBadge(
                        systemName: tripScope == .active ? "suitcase" : "clock.arrow.circlepath",
                        role: .booking,
                        size: 42,
                        symbolSize: 18,
                        cornerRadius: 14
                    )
                    Text(tr(
                        tripScope == .active ? "No active trips yet." : "Previous trips will appear here.",
                        tripScope == .active ? "Активных поездок пока нет." : "Здесь появится история прошлых поездок.",
                        tripScope == .active ? "Hozircha faol safar yo‘q." : "Oldingi safarlar tarixi shu yerda ko‘rinadi.",
                        tripScope == .active ? "Ҳозирча фаол сафар йўқ." : "Олдинги сафарлар тарихи шу ерда кўринади."
                    ))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .padding(16)
                .background(Color.iumrahRaisedBackground.opacity(0.58), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(scopedAccountTrips.prefix(3).enumerated()), id: \.element.id) { index, session in
                        Button { chrome.openBooking(id: session.id) } label: {
                            tripRow(session)
                        }
                        .buttonStyle(.plain)
                        if index < min(scopedAccountTrips.count, 3) - 1 {
                            Divider().padding(.leading, 54)
                        }
                    }
                }
                .padding(.horizontal, 4)

                if scopedAccountTrips.count > 3 {
                    NavigationLink {
                        IumrahTripsHistoryView(
                            sessions: allTrips,
                            initialScopePast: tripScope == .past
                        )
                    } label: {
                        HStack {
                            Text(tr("Open all trips", "Открыть все поездки", "Barcha safarlarni ochish", "Барча сафарларни очиш"))
                                .font(.subheadline.weight(.semibold))
                            Spacer()
                            Image(systemName: "arrow.right")
                                .font(.caption.weight(.bold))
                        }
                        .padding(.horizontal, 14)
                        .frame(height: 48)
                        .foregroundStyle(.primary)
                        .iumrahGlass(in: RoundedRectangle(cornerRadius: 16, style: .continuous), interactive: true)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .iumrahCard()
    }

    private func userDataEntryCard(_ profile: IumrahAccountProfile) -> some View {
        NavigationLink {
            IumrahUserDataView()
        } label: {
            HStack(spacing: 15) {
                Image(systemName: "person.crop.circle.fill")
                    .font(.system(size: 23, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 56, height: 56)
                    .iumrahGlass(in: RoundedRectangle(cornerRadius: 18), tint: Color.white.opacity(0.11), allowsStaticGlass: true)

                VStack(alignment: .leading, spacing: 5) {
                    Text(displayName(profile))
                        .font(.system(size: 21, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(1)

                    Text(tr(
                        "Your booking and account details",
                        "Ваши данные бронирования и аккаунта",
                        "Bron va akkaunt ma’lumotlaringiz",
                        "Брон ва аккаунт маълумотларингиз"
                    ))
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.68))
                    .lineLimit(2)

                    Label(
                        userDataReady
                            ? tr("Profile ready", "Профиль заполнен", "Profil tayyor", "Профил тайёр")
                            : tr("Complete your profile", "Заполните данные", "Ma’lumotlarni to‘ldiring", "Маълумотларни тўлдиринг"),
                        systemImage: userDataReady ? "checkmark.circle.fill" : "exclamationmark.circle.fill"
                    )
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(userDataReady ? Color.green : Color.orange)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white.opacity(0.52))
            }
            .padding(.vertical, 6)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var travelCompanionsEntryCard: some View {
        NavigationLink {
            IumrahTravelCompanionsView()
        } label: {
            VStack(alignment: .leading, spacing: 0) {
                Image("TravelCompanionsCover")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .frame(height: 118)
                    .clipped()
                    .overlay(alignment: .bottom) {
                        LinearGradient(
                            colors: [.clear, Color.black.opacity(0.18)],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                        .allowsHitTesting(false)
                    }

                HStack(spacing: 14) {
                    IumrahIconBadge(
                        systemName: "person.2.fill",
                        role: .profile,
                        size: 50,
                        symbolSize: 20,
                        cornerRadius: 16
                    )

                    VStack(alignment: .leading, spacing: 4) {
                        Text(tr("Who is traveling with you", "Кто едет с Вами", "Siz bilan kim bormoqda", "Сиз билан ким бормоқда"))
                            .font(.system(size: 19, weight: .bold, design: .rounded))
                            .foregroundStyle(.primary)

                        Text(tr(
                            "Family, loved ones, traveler cards and emergency contact",
                            "Семья, близкие, карточки участников и экстренный контакт",
                            "Oila, yaqinlar, sayohatchi kartalari va favqulodda kontakt",
                            "Оила, яқинлар, саёҳатчи карталари ва фавқулодда контакт"
                        ))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.tertiary)
                }
                .padding(16)
            }
            .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.8)
            }
            .shadow(color: .black.opacity(0.045), radius: 18, y: 8)
        }
        .buttonStyle(.plain)
    }

    private var userDataReady: Bool {
        guard let profile = account.account else { return false }
        let hasName = !profile.firstName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
            !profile.lastName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        let hasContact = !profile.phone.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
            !profile.email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        let hasPersonal = !settings.dateOfBirth.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
            !settings.gender.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
            !settings.nationality.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        return hasName && hasContact && hasPersonal
    }

    private func profileSection(_ profile: IumrahAccountProfile) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 12) {
                sectionHeader(
                    icon: "person.text.rectangle.fill",
                    title: tr("Account details", "Данные аккаунта", "Akkaunt ma’lumotlari", "Аккаунт маълумотлари"),
                    subtitle: tr("Used for your profile and future trips", "Используются в профиле и новых поездках", "Profil va yangi safarlarda ishlatiladi", "Профил ва янги сафарларда ишлатилади")
                )
                Spacer(minLength: 4)
                Button {
                    loadProfileDraftIfNeeded(force: true, profile: profile)
                    profileMessage = nil
                    showProfileEditor = true
                    IumrahHaptics.selection()
                } label: {
                    Label(tr("Edit", "Изменить", "Tahrirlash", "Таҳрирлаш"), systemImage: "pencil")
                        .font(.caption.weight(.bold))
                        .padding(.horizontal, 12)
                        .frame(height: 38)
                        .iumrahGlass(in: Capsule(), interactive: true)
                }
                .buttonStyle(.plain)
            }

            VStack(spacing: 0) {
                accountSummaryRow(icon: "person.fill", role: .profile, title: tr("Name", "Имя", "Ism", "Исм"), value: displayName(profile))
                Divider().padding(.leading, 52)
                accountSummaryRow(icon: "phone.fill", role: .phone, title: tr("Phone", "Телефон", "Telefon", "Телефон"), value: profile.phone)
                Divider().padding(.leading, 52)
                accountSummaryRow(icon: "envelope.fill", role: .mail, title: "Email", value: profile.email)
                Divider().padding(.leading, 52)
                accountSummaryRow(icon: "paperplane.fill", role: .telegram, title: "Telegram", value: profile.telegram)
                Divider().padding(.leading, 52)
                accountSummaryRow(icon: "message.fill", role: .whatsapp, title: "WhatsApp", value: profile.whatsapp)
            }
            .padding(.horizontal, 4)
        }
        .iumrahCard()
        .onAppear { loadProfileDraftIfNeeded(force: false, profile: profile) }
    }

    private func accountSummaryRow(icon: String, role: IumrahIconRole, title: String, value: String) -> some View {
        HStack(spacing: 12) {
            IumrahIconBadge(systemName: icon, role: role, size: 38, symbolSize: 14, cornerRadius: 12)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "—" : value)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? Color.secondary : Color.primary)
                    .lineLimit(2)
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 9)
    }

    private var profileEditorSheet: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 7) {
                        Text(tr("Account details", "Данные аккаунта", "Akkaunt ma’lumotlari", "Аккаунт маълумотлари"))
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                        Text(tr("These details are reused for future Iumrah trips.", "Эти данные будут использоваться для Ваших следующих поездок Iumrah.", "Bu ma’lumotlar keyingi Iumrah safarlarida ishlatiladi.", "Бу маълумотлар кейинги Iumrah сафарларида ишлатилади."))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    VStack(spacing: 12) {
                        accountField(tr("First name", "Имя", "Ism", "Исм"), text: $firstName, contentType: .givenName)
                        accountField(tr("Last name", "Фамилия", "Familiya", "Фамилия"), text: $lastName, contentType: .familyName)
                        accountField(tr("Phone", "Телефон", "Telefon", "Телефон"), text: $phone, keyboard: .phonePad, contentType: .telephoneNumber)
                        accountField("Email", text: $email, keyboard: .emailAddress, contentType: .emailAddress, autocapitalization: .never)
                        accountField("Telegram", text: $telegram, autocapitalization: .never)
                        accountField("WhatsApp", text: $whatsapp, keyboard: .phonePad, contentType: .telephoneNumber)
                    }
                    .padding(16)
                    .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 26, style: .continuous))

                    if let profileMessage {
                        Text(profileMessage)
                            .font(.footnote)
                            .foregroundStyle(profileMessage == savedText ? Color.green : Color.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    Button {
                        Task { await saveProfile(dismissAfterSave: true) }
                    } label: {
                        HStack(spacing: 10) {
                            if isSavingProfile { ProgressView().tint(.white) }
                            
                            Text(tr("Save account details", "Сохранить данные аккаунта", "Akkaunt ma’lumotlarini saqlash", "Аккаунт маълумотларини сақлаш"))
                            
                        }
                    }
                    .buttonStyle(IumrahPrimaryButtonStyle())
                    .disabled(firstName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || lastName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isSavingProfile)
                }
                .padding(.horizontal, IumrahDesign.pagePadding)
                .padding(.top, 18)
                .padding(.bottom, 36)
            }
            .background(Color.iumrahPageBackground)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(tr("Close", "Закрыть", "Yopish", "Ёпиш")) { showProfileEditor = false }
                }
            }
        }
    }

    private var telegramIntegrationSection: some View {
        NavigationLink {
            IumrahTelegramIntegrationView(preferredBookingID: activeTrip?.id)
        } label: {
            IumrahTelegramEntryCard(language: settings.language, large: false)
        }
        .buttonStyle(.plain)
    }

    private var paymentSecuritySection: some View {
        VStack(alignment: .leading, spacing: 4) {
            sectionHeader(
                icon: "creditcard.and.123",
                title: tr("Payment & privacy", "Оплата и правила", "To‘lov va qoidalar", "Тўлов ва қоидалар"),
                subtitle: tr(
                    "Payment methods, refunds and privacy",
                    "Способы оплаты, возвраты и конфиденциальность",
                    "To‘lov usullari, qaytarish va maxfiylik",
                    "Тўлов усуллари, қайтариш ва махфийлик"
                )
            )
            .padding(.bottom, 8)

            IumrahPaymentMethodsMarquee(compact: true)
                .padding(.bottom, 8)

            NavigationLink {
                IumrahPolicyDetailView(kind: .paymentSecurity)
            } label: {
                settingsRow(
                    icon: "creditcard.fill",
                    title: tr("Payment", "Оплата", "To‘lov", "Тўлов"),
                    value: tr(
                        "Method, confirmation and payment security",
                        "Способ, подтверждение и безопасность платежа",
                        "Usul, tasdiqlash va to‘lov xavfsizligi",
                        "Усул, тасдиқлаш ва тўлов хавфсизлиги"
                    )
                )
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            NavigationLink {
                IumrahPolicyDetailView(kind: .refund)
            } label: {
                settingsRow(
                    icon: "arrow.uturn.backward.circle.fill",
                    title: IumrahPolicyKind.refund.title(settings.language),
                    value: tr(
                        "Flights, hotels, transfer and services",
                        "Авиабилеты, отели, трансфер и сервисы",
                        "Aviachipta, mehmonxona, transfer va xizmatlar",
                        "Авиачипта, меҳмонхона, трансфер ва хизматлар"
                    )
                )
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            NavigationLink {
                IumrahPolicyDetailView(kind: .privacy)
            } label: {
                settingsRow(
                    icon: "hand.raised.fill",
                    title: IumrahPolicyKind.privacy.title(settings.language),
                    value: tr(
                        "Personal data and privacy",
                        "Персональные данные и конфиденциальность",
                        "Shaxsiy ma’lumotlar va maxfiylik",
                        "Шахсий маълумотлар ва махфийлик"
                    )
                )
            }
            .buttonStyle(.plain)

        }
        .iumrahCard()
    }

    private var servicesSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            sectionHeader(
                icon: "square.grid.2x2.fill",
                title: tr("Services", "Сервисы", "Xizmatlar", "Хизматлар"),
                subtitle: tr(
                    "All key iumrah tools in one place",
                    "Все основные функции iumrah в одном месте",
                    "iumrah asosiy funksiyalari bir joyda",
                    "iumrah асосий функциялари бир жойда"
                )
            )
            .padding(.bottom, 8)

            NavigationLink {
                IumrahFlightsView(preferredBookingID: activeTrip?.id)
            } label: {
                settingsRow(
                    icon: "airplane.circle.fill",
                    title: tr("iumrah Flights status", "iumrah Flights статус", "iumrah Flights holati", "iumrah Flights ҳолати"),
                    value: tr(
                        "Live flight status, route and travel updates",
                        "Статус рейса, маршрут и обновления поездки",
                        "Reys holati, yo‘nalish va safar yangiliklari",
                        "Рейс ҳолати, йўналиш ва сафар янгиликлари"
                    )
                )
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            NavigationLink {
                ZiyaratJourneyView()
            } label: {
                settingsRow(
                    icon: "map.fill",
                    title: "iumrah Ziyarats",
                    value: tr(
                        "Makkah and Madinah places, route and navigation",
                        "Места Мекки и Медины, маршрут и навигация",
                        "Makka va Madina joylari, yo‘nalish va navigatsiya",
                        "Макка ва Мадина жойлари, йўналиш ва навигация"
                    )
                )
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            NavigationLink {
                ESIMView()
            } label: {
                settingsRow(
                    icon: "simcard.fill",
                    title: "iumrah eSIM",
                    value: tr(
                        "Saudi connectivity and eSIM status",
                        "Связь в Саудии и статус eSIM",
                        "Saudiya aloqasi va eSIM holati",
                        "Саудия алоқаси ва eSIM ҳолати"
                    )
                )
            }
            .buttonStyle(.plain)


        }
        .iumrahCard()
    }

    private var settingsSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            sectionHeader(
                icon: "gearshape.fill",
                title: tr("Settings", "Настройки", "Sozlamalar", "Созламалар"),
                subtitle: tr(
                    "Language, appearance and notifications",
                    "Язык, оформление и уведомления",
                    "Til, ko‘rinish va bildirishnomalar",
                    "Тил, кўриниш ва билдиришномалар"
                )
            )
            .padding(.bottom, 8)

            if account.isAuthenticated {
                NavigationLink {
                    IumrahAccountSecurityView()
                } label: {
                    settingsRow(
                        icon: "lock.shield.fill",
                        title: tr("Account security", "Безопасность аккаунта", "Akkaunt xavfsizligi", "Аккаунт хавфсизлиги"),
                        value: tr("Apple, Google and active sessions", "Apple, Google и активные сеансы", "Apple, Google va faol seanslar", "Apple, Google ва фаол сеанслар")
                    )
                }
                .buttonStyle(.plain)

                Divider().padding(.leading, 54)
            }

            Button {
                IumrahHaptics.soft()
                showLanguageSheet = true
            } label: {
                settingsRow(icon: "globe", title: tr("Language", "Язык", "Til", "Тил"), value: settings.language.title)
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            NavigationLink {
                IumrahAppearanceView()
            } label: {
                settingsRow(
                    icon: "circle.lefthalf.filled",
                    title: tr("Appearance", "Оформление", "Ko‘rinish", "Кўриниш"),
                    value: settings.appearance.title(settings.language)
                )
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            NavigationLink {
                AccountNotificationsView()
            } label: {
                settingsRow(icon: "bell.and.waves.left.and.right.fill", title: tr("Umrah status signal", "Umra статус сигнал", "Umra holat signali", "Умра ҳолат сигнали"), value: signalHistoryValueText)
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            Button {
                openSystemSettings()
            } label: {
                settingsRow(
                    icon: "bell.badge.fill",
                    title: tr("Notifications", "Уведомления", "Bildirishnomalar", "Билдиришномалар"),
                    value: notificationStatusText
                )
            }
            .buttonStyle(.plain)
        }
        .iumrahCard()
    }

    private var signOutButton: some View {
        Button(role: .destructive) {
            showSignOutConfirmation = true
        } label: {
            HStack(spacing: 10) {
                Image(systemName: "rectangle.portrait.and.arrow.right")
                Text(tr("Disconnect this device", "Отключить профиль на устройстве", "Profilni qurilmadan uzish", "Профилни қурилмадан узиш"))
                Spacer()
            }
            .padding(.horizontal, 18)
            .frame(height: 56)
            .foregroundStyle(.red)
            .background(Color.red.opacity(0.075), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var guestCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            IumrahIconBadge(systemName: "person.crop.circle.badge.key.fill", role: .security, size: 54, symbolSize: 25, cornerRadius: 18)

            Text(tr("Your permanent iumrah account", "Ваш постоянный аккаунт iumrah", "Doimiy iumrah akkauntingiz", "Доимий iumrah аккаунтингиз"))
                .font(.system(size: 27, weight: .bold, design: .rounded))
            Text(tr("Sign in once to restore all trips after reinstalling the app and automatically link future bookings to the same ID.", "Войдите один раз, чтобы восстанавливать все поездки после переустановки приложения и автоматически привязывать новые брони к одному ID.", "Ilovani qayta o‘rnatgandan keyin barcha safarlarni tiklash va yangi bronlarni bitta ID ga bog‘lash uchun kiring.", "Иловани қайта ўрнатгандан кейин барча сафарларни тиклаш ва янги бронларни битта ID га боғлаш учун киринг."))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .iumrahCard()
    }

    private var guestOrbitHero: some View {
        VStack(spacing: 12) {
            IumrahOrbitAdaptive(maxDiameter: 310, logo: Image("IumrahOrbitAccountLogo"),
                               accessibilityTitle: "iumrah Account", isActive: chrome.currentTab == .account)
                .accessibilityIdentifier("iumrah.orbit.account.v5")
            Text(tr("One account for all iumrah services", "Один аккаунт для всех сервисов iumrah", "Barcha iumrah xizmatlari uchun bitta akkaunt", "Барча iumrah хизматлари учун битта аккаунт"))
                .font(.system(size: 25, weight: .bold, design: .rounded))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            Text(tr("Manage your trips, documents and bookings in one place.", "Управляйте поездками, документами и бронированиями в одном месте.", "Safarlar, hujjatlar va bronlarni bir joyda boshqaring.", "Сафарлар, ҳужжатлар ва бронларни бир жойда бошқаринг."))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            Button {
                guestAccountMode = .signIn
                loginScrollNonce += 1
            } label: {
                Text(tr("Sign in", "Войти", "Kirish", "Кириш"))
                    .font(.headline).frame(maxWidth: .infinity).frame(minHeight: 52)
                    .foregroundStyle(colorScheme == .dark ? Color.black : Color.white)
                    .background(colorScheme == .dark ? Color.white : Color.black, in: RoundedRectangle(cornerRadius: 16))
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("iumrah.account.orbit.signin")
            Button {
                guestAccountMode = .register
                loginScrollNonce += 1
            } label: {
                Text(tr("Create account", "Создать аккаунт", "Akkaunt yaratish", "Аккаунт яратиш"))
                    .font(.headline).frame(maxWidth: .infinity).frame(minHeight: 52)
                    .foregroundStyle(Color.primary)
                    .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(Color.primary.opacity(0.18)))
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("iumrah.account.orbit.register")
        }
        .padding(16)
        .frame(maxWidth: .infinity)
        .iumrahCard()
    }

    private var loginCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(
                icon: guestAccountMode == .signIn ? "key.fill" : "person.badge.plus",
                title: guestAccountMode == .signIn
                    ? tr("Sign in", "Вход", "Kirish", "Кириш")
                    : tr("Create account", "Регистрация", "Ro‘yxatdan o‘tish", "Рўйхатдан ўтиш"),
                subtitle: guestAccountMode == .signIn
                    ? tr("Use the method linked to your permanent iumrah account", "Используйте способ, привязанный к Вашему постоянному аккаунту iumrah", "Doimiy iumrah akkauntingizga ulangan usuldan foydalaning", "Доимий iumrah аккаунтингизга уланган усулдан фойдаланинг")
                    : tr("Create one permanent account for all future trips", "Создайте один постоянный аккаунт для всех будущих поездок", "Barcha keyingi safarlar uchun bitta doimiy akkaunt yarating", "Барча кейинги сафарлар учун битта доимий аккаунт яратинг")
            )

            Picker("", selection: $guestAuthMethod) {
                Text("SMS").tag(IumrahGuestAuthMethod.sms)
                Text("Email").tag(IumrahGuestAuthMethod.email)
            }
            .pickerStyle(.segmented)
            .onChange(of: guestAuthMethod) { _, _ in
                loginError = nil
                loginEmailServerIssue = nil
                resetPhoneLoginState()
                resetPhoneRegistrationState()
            }

            if guestAccountMode == .signIn {
                guestSignInFields
            } else {
                guestRegistrationFields
            }

            if guestAccountMode == .register || !pendingReferralCode.isEmpty {
                VStack(alignment: .leading, spacing: 10) {
                    Text(tr("Invitation code (optional)", "Код приглашения (необязательно)", "Taklif kodi (ixtiyoriy)", "Таклиф коди (ихтиёрий)")).font(.subheadline.weight(.semibold))
                    TextField("IUMR-…", text: $pendingReferralCode)
                        .textInputAutocapitalization(.characters).autocorrectionDisabled()
                        .padding(12).background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 12))
                        .onChange(of: pendingReferralCode) { _, _ in referralConsent = false }
                    if IumrahReferralLink.normalized(pendingReferralCode) != nil {
                        Toggle(tr("Share my name, pilgrim ID and referral progress with the inviter", "Разрешаю показать пригласившему моё имя, ID паломника и статус приглашения", "Taklif qiluvchiga ismim, ID va taklif holatini ko‘rsatishga roziman", "Таклиф қилувчига исмим, ID ва таклиф ҳолатини кўрсатишга розиман"), isOn: $referralConsent).font(.footnote)
                    }
                }
            }
            if let loginError {
                Text(loginError)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack(spacing: 12) {
                Rectangle().fill(Color.secondary.opacity(0.20)).frame(height: 1)
                Text(tr("or", "или", "yoki", "ёки"))
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                Rectangle().fill(Color.secondary.opacity(0.20)).frame(height: 1)
            }

            IumrahLocalizedAppleAuthButton(
                title: guestAccountMode == .signIn
                    ? tr("Sign in with Apple", "Войти с Apple", "Apple orqali kirish", "Apple орқали кириш")
                    : tr("Continue with Apple", "Продолжить с Apple", "Apple bilan davom etish", "Apple билан давом этиш"),
                isDisabled: isAppleSigningIn || isGoogleSigningIn || isLoggingIn || isRegistering,
                onRequest: prepareAppleSignIn,
                onCompletion: completeAppleSignIn
            )

            IumrahGoogleAuthButton(
                title: guestAccountMode == .signIn
                    ? tr("Sign in with Google", "Войти с Google", "Google orqali kirish", "Google орқали кириш")
                    : tr("Continue with Google", "Продолжить с Google", "Google bilan davom etish", "Google билан давом этиш"),
                isDisabled: isGoogleSigningIn || isAppleSigningIn || isLoggingIn || isRegistering
            ) {
                startGoogleSignIn()
            }

            Text(tr(
                "Apple and Google use the same permanent iumrah account; they do not create a separate trip profile.",
                "Apple и Google используют тот же постоянный аккаунт iumrah и не создают отдельный профиль поездки.",
                "Apple va Google aynan shu doimiy iumrah akkauntidan foydalanadi va alohida safar profili yaratmaydi.",
                "Apple ва Google айнан шу доимий iumrah аккаунтидан фойдаланади ва алоҳида сафар профили яратмайди."
            ))
            .font(.caption)
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)
        }
        .iumrahCard()
    }

    @ViewBuilder
    private var guestSignInFields: some View {
        switch guestAuthMethod {
        case .email:
            accountInputField(symbol: "envelope.fill", placeholder: "name@example.com", text: $loginEmail, keyboard: .emailAddress, contentType: .emailAddress) { raw in
                loginEmail = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                loginEmailServerIssue = nil
            }
            .disabled(!loginEmailChallengeID.isEmpty)
            if let issue = loginEmailFieldIssue { fieldIssueView(issue) }
            if !loginEmailChallengeID.isEmpty {
                accountInputField(symbol: "number.square.fill", placeholder: tr("6-digit code", "Код из 6 цифр", "6 xonali kod", "6 хонали код"), text: $loginEmailCode, keyboard: .numberPad, contentType: .oneTimeCode) { raw in
                    loginEmailCode = String(raw.filter(\.isNumber).prefix(6))
                }
                Button(tr("Change email", "Изменить email", "Emailni o‘zgartirish", "Emailни ўзгартириш")) {
                    loginEmailChallengeID = ""; loginEmailCode = ""
                }
            }
            Button { Task { await login() } } label: {
                Text(loginEmailChallengeID.isEmpty
                    ? tr("Send code", "Отправить код", "Kodni yuborish", "Кодни юбориш")
                    : tr("Confirm and sign in", "Подтвердить и войти", "Tasdiqlab kirish", "Тасдиқлаб кириш"))
            }
            .buttonStyle(IumrahPrimaryButtonStyle())
            .disabled(!guestLoginReady || isLoggingIn || isAppleSigningIn || isGoogleSigningIn)

        case .sms:
            accountInputField(symbol: "phone.fill", placeholder: "+998 90 123 45 67", text: $loginPhone, keyboard: .phonePad, contentType: .telephoneNumber) { raw in
                let formatted = normalizedUZPhoneInput(raw)
                if formatted != raw { loginPhone = formatted }
            }
            if !loginPhone.isEmpty && !normalizedUZPhoneInput(loginPhone).hasPrefix("+998") {
                unsupportedSMSNotice
            } else {
                Text(loginSMSChallengeID.isEmpty
                     ? tr(
                        "We will send a 6-digit sign-in code to your Uzbekistan number through DevSMS.",
                        "Мы отправим 6-значный код входа на Ваш номер Узбекистана через DevSMS.",
                        "DevSMS orqali O‘zbekiston raqamingizga 6 xonali kirish kodi yuboramiz.",
                        "DevSMS орқали Ўзбекистон рақамингизга 6 хонали кириш коди юборамиз."
                     )
                     : tr(
                        "Enter the code from SMS. It is valid for 10 minutes.",
                        "Введите код из SMS. Он действует 10 минут.",
                        "SMS dagi kodni kiriting. U 10 daqiqa amal qiladi.",
                        "SMS даги кодни киритинг. У 10 дақиқа амал қилади."
                     ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if !loginSMSChallengeID.isEmpty {
                accountInputField(symbol: "number.square.fill", placeholder: tr("6-digit code", "Код из 6 цифр", "6 xonali kod", "6 хонали код"), text: $loginSMSCode, keyboard: .numberPad, contentType: .oneTimeCode) { raw in
                    let digits = String(raw.filter(\.isNumber).prefix(6))
                    if digits != raw { loginSMSCode = digits }
                }
            }

            Button {
                Task {
                    if loginSMSChallengeID.isEmpty { await startPhoneLogin() }
                    else { await confirmPhoneLogin() }
                }
            } label: {
                HStack(spacing: 10) {
                    if isLoggingIn { ProgressView().tint(.white) }
                    
                    Text(loginSMSChallengeID.isEmpty
                         ? tr("Send SMS code", "Отправить SMS-код", "SMS kodni yuborish", "SMS кодни юбориш")
                         : tr("Confirm and sign in", "Подтвердить и войти", "Tasdiqlab kirish", "Тасдиқлаб кириш"))
                    
                    
                }
            }
            .buttonStyle(IumrahPrimaryButtonStyle())
            .disabled(!guestLoginReady || isLoggingIn || isAppleSigningIn || isGoogleSigningIn)
        }
    }

    @ViewBuilder
    private var guestRegistrationFields: some View {
        switch guestAuthMethod {
        case .email:
            HStack(spacing: 10) {
                accountInputField(symbol: "person.fill", placeholder: tr("First name", "Имя", "Ism", "Исм"), text: $registrationFirstName, keyboard: .default, contentType: .givenName)
                accountInputField(symbol: "person.fill", placeholder: tr("Last name", "Фамилия", "Familiya", "Фамилия"), text: $registrationLastName, keyboard: .default, contentType: .familyName)
            }

            accountInputField(symbol: "envelope.fill", placeholder: "name@example.com", text: $registrationEmail, keyboard: .emailAddress, contentType: .emailAddress) { raw in
                let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                if cleaned != raw { registrationEmail = cleaned }
                registrationEmailIssue = nil
            }
            .disabled(!registrationEmailChallengeID.isEmpty)

            if let issue = registrationEmailFieldIssue {
                fieldIssueView(issue)
            }

            if !registrationEmailChallengeID.isEmpty {
                accountInputField(symbol: "number.square.fill", placeholder: tr("6-digit code", "Код из 6 цифр", "6 xonali kod", "6 хонали код"), text: $registrationEmailCode, keyboard: .numberPad, contentType: .oneTimeCode) { raw in
                    let digits = String(raw.filter(\.isNumber).prefix(6))
                    if digits != raw { registrationEmailCode = digits }
                }


            }

            Button {
                Task {
                    if registrationEmailChallengeID.isEmpty { await startGuestEmailRegistration() }
                    else { await confirmGuestEmailRegistration() }
                }
            } label: {
                HStack {
                    if isRegistering { ProgressView().tint(.white) }
                    Text(registrationEmailChallengeID.isEmpty
                         ? tr("Send verification code", "Отправить код", "Tasdiqlash kodini yuborish", "Тасдиқлаш кодини юбориш")
                         : tr("Create iumrah account", "Создать аккаунт iumrah", "iumrah akkauntini yaratish", "iumrah аккаунтини яратиш"))
                    
                    
                }
            }
            .buttonStyle(IumrahPrimaryButtonStyle())
            .disabled(!guestEmailRegistrationReady || isRegistering || isAppleSigningIn || isGoogleSigningIn)

        case .sms:
            HStack(spacing: 10) {
                accountInputField(
                    symbol: "person.fill",
                    placeholder: tr("First name", "Имя", "Ism", "Исм"),
                    text: $registrationFirstName,
                    keyboard: .default,
                    contentType: .givenName
                )
                .disabled(!registrationSMSChallengeID.isEmpty)

                accountInputField(
                    symbol: "person.fill",
                    placeholder: tr("Last name", "Фамилия", "Familiya", "Фамилия"),
                    text: $registrationLastName,
                    keyboard: .default,
                    contentType: .familyName
                )
                .disabled(!registrationSMSChallengeID.isEmpty)
            }

            accountInputField(
                symbol: "phone.fill",
                placeholder: "+998 90 123 45 67",
                text: $registrationPhone,
                keyboard: .phonePad,
                contentType: .telephoneNumber
            ) { raw in
                let formatted = normalizedUZPhoneInput(raw)
                if formatted != raw { registrationPhone = formatted }
            }
            .disabled(!registrationSMSChallengeID.isEmpty)

            if !registrationPhone.isEmpty && !normalizedUZPhoneInput(registrationPhone).hasPrefix("+998") {
                unsupportedSMSNotice
            } else {
                Text(registrationSMSChallengeID.isEmpty
                     ? tr(
                        "Create your permanent iumrah account with a 6-digit SMS code. Uzbekistan +998 numbers are supported.",
                        "Создайте постоянный аккаунт iumrah по 6-значному SMS-коду. Поддерживаются номера Узбекистана +998.",
                        "Doimiy iumrah akkauntingizni 6 xonali SMS kodi bilan yarating. +998 O‘zbekiston raqamlari qo‘llanadi.",
                        "Доимий iumrah аккаунтингизни 6 хонали SMS коди билан яратинг. +998 Ўзбекистон рақамлари қўлланади."
                     )
                     : tr(
                        "Enter the SMS code, then create a password for iumrah ID sign-in as a backup.",
                        "Введите SMS-код, затем создайте пароль для резервного входа по iumrah ID.",
                        "Akkauntni tasdiqlash uchun SMS kodni kiriting.",
                        "Аккаунтни тасдиқлаш учун SMS кодни киритинг."
                     ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if !registrationSMSChallengeID.isEmpty {
                accountInputField(
                    symbol: "number.square.fill",
                    placeholder: tr("6-digit code", "Код из 6 цифр", "6 xonali kod", "6 хонали код"),
                    text: $registrationSMSCode,
                    keyboard: .numberPad,
                    contentType: .oneTimeCode
                ) { raw in
                    let digits = String(raw.filter(\.isNumber).prefix(6))
                    if digits != raw { registrationSMSCode = digits }
                }


            }

            Button {
                Task {
                    if registrationSMSChallengeID.isEmpty {
                        await startGuestSMSRegistration()
                    } else {
                        await confirmGuestSMSRegistration()
                    }
                }
            } label: {
                HStack(spacing: 10) {
                    if isRegistering { ProgressView().tint(.white) }
                    
                    Text(registrationSMSChallengeID.isEmpty
                         ? tr("Send SMS code", "Отправить SMS-код", "SMS kodni yuborish", "SMS кодни юбориш")
                         : tr("Create iumrah account", "Создать аккаунт iumrah", "iumrah akkauntini yaratish", "iumrah аккаунтини яратиш"))
                    
                    
                }
            }
            .buttonStyle(IumrahPrimaryButtonStyle())
            .disabled(!guestSMSRegistrationReady || isRegistering || isAppleSigningIn || isGoogleSigningIn)

        }
    }

    @ViewBuilder
    private var pendingActivationButton: some View {
        if let pending = pendingActivationTrip {
            NavigationLink {
                PilgrimCheckoutView(bookingID: pending.id)
            } label: {
                HStack {
                    Text(tr("Open booking activation", "Открыть активацию брони", "Bron faollashtirishini ochish", "Брон фаоллаштиришини очиш"))
                }
            }
            .buttonStyle(IumrahPrimaryButtonStyle())
        } else {
            Text(tr(
                "There is no booking awaiting account activation on this device yet. You can register by Email, Apple or Google now.",
                "На этом устройстве пока нет брони, ожидающей активации аккаунта. Сейчас можно зарегистрироваться по Email, Apple или Google.",
                "Bu qurilmada akkaunt faollashtirishini kutayotgan bron hali yo‘q. Hozir Email, Apple yoki Google orqali ro‘yxatdan o‘tishingiz mumkin.",
                "Бу қурилмада аккаунт фаоллаштиришини кутаётган брон ҳали йўқ. Ҳозир Email, Apple ёки Google орқали рўйхатдан ўтишингиз мумкин."
            ))
            .font(.caption)
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func bookingBoundRegistrationNotice(icon: String, title: String, text: String) -> some View {
        HStack(alignment: .top, spacing: 11) {
            Image(systemName: icon)
                .foregroundStyle(Color.blue)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(text).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .background(Color.blue.opacity(0.075), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay { RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(Color.blue.opacity(0.16), lineWidth: 0.8) }
    }

    private var unsupportedSMSNotice: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.bubble.fill")
                .foregroundStyle(.orange)
            Text(tr(
                "SMS is temporarily unavailable for this country. Continue by Email or use Google or Apple. SMS currently supports Uzbekistan numbers beginning with +998.",
                "SMS для этой страны временно недоступны. Продолжите по Email или используйте Google либо Apple. Сейчас SMS поддерживает номера Узбекистана, начинающиеся с +998.",
                "Bu davlat uchun SMS vaqtincha mavjud emas. Email orqali davom eting yoki Google/Apple’dan foydalaning. Hozir SMS faqat +998 bilan boshlanuvchi O‘zbekiston raqamlarini qo‘llaydi.",
                "Бу давлат учун SMS вақтинча мавжуд эмас. Email орқали давом этинг ёки Google/Apple’дан фойдаланинг. Ҳозир SMS фақат +998 билан бошланувчи Ўзбекистон рақамларини қўллайди."
            ))
            .font(.caption.weight(.medium))
            .foregroundStyle(.orange)
            .fixedSize(horizontal: false, vertical: true)
        }
        .padding(13)
        .background(Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
        .overlay { RoundedRectangle(cornerRadius: 17, style: .continuous).strokeBorder(Color.orange.opacity(0.18), lineWidth: 0.8) }
    }

    private func accountInputField(
        symbol: String,
        placeholder: String,
        text: Binding<String>,
        keyboard: UIKeyboardType,
        contentType: UITextContentType?,
        onChange: ((String) -> Void)? = nil
    ) -> some View {
        HStack(spacing: 11) {
            Image(systemName: symbol)
                .foregroundStyle(.secondary)
                .frame(width: 22)
            TextField(placeholder, text: text)
                .keyboardType(keyboard)
                .textContentType(contentType)
                .textInputAutocapitalization(keyboard == .emailAddress ? .never : .words)
                .autocorrectionDisabled(keyboard == .emailAddress)
                .onChange(of: text.wrappedValue) { _, raw in onChange?(raw) }
        }
        .padding(.horizontal, 16)
        .frame(minHeight: 56)
        .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.8)
        }
    }

    private func accountPasswordField(text: Binding<String>, placeholder: String) -> some View {
        HStack(spacing: 11) {
            Image(systemName: "lock.fill")
                .foregroundStyle(.secondary)
                .frame(width: 22)
            SecureField(placeholder, text: text)
                .textContentType(.password)
        }
        .padding(.horizontal, 16)
        .frame(height: 56)
        .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.8)
        }
    }

    private var guestLoginReady: Bool {
        switch guestAuthMethod {
        case .email:
            return loginEmailFieldIssue == nil && !loginEmail.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && (loginEmailChallengeID.isEmpty || loginEmailCode.count == 6)
        case .sms:
            let phoneReady = normalizedUZPhoneInput(loginPhone).count == 13 && normalizedUZPhoneInput(loginPhone).hasPrefix("+998")
            if !phoneReady { return false }
            if loginSMSChallengeID.isEmpty { return true }
            return loginSMSCode.count == 6
        }
    }

    private var guestEmailRegistrationReady: Bool {
        let mail = registrationEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        guard registrationEmailFieldIssue == nil,
              !mail.isEmpty,
              !registrationFirstName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !registrationLastName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return false }
        if registrationEmailChallengeID.isEmpty { return true }
        return registrationEmailCode.count == 6
    }


    private var guestSMSRegistrationReady: Bool {
        let phone = normalizedUZPhoneInput(registrationPhone)
        guard phone.hasPrefix("+998"), phone.count == 13,
              !registrationFirstName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !registrationLastName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return false }
        if registrationSMSChallengeID.isEmpty { return true }
        return registrationSMSCode.count == 6
    }

    private func activationShortcut(_ session: StoredBookingSession) -> some View {
        NavigationLink {
            PilgrimCheckoutView(bookingID: session.id)
        } label: {
            HStack(spacing: 14) {
                IumrahIconBadge(systemName: "person.badge.key.fill", role: .security, size: 46, symbolSize: 19, cornerRadius: 15)
                VStack(alignment: .leading, spacing: 3) {
                    Text(tr("Activate your iumrah ID", "Активировать iumrah ID", "iumrah ID ni faollashtirish", "iumrah ID ни фаоллаштириш"))
                        .font(.subheadline.weight(.bold))
                    if let id = session.displayPilgrimID {
                        Text("ID \(id) · \(tr("booking ready for details", "бронь готова к заполнению", "bron ma’lumotlarga tayyor", "брон маълумотларга тайёр"))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 10)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .padding(16)
            .background(Color.iumrahCardBackground, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay { RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(Color.primary.opacity(0.055), lineWidth: 1) }
        }
        .buttonStyle(.plain)
    }

    private var guestSettingsSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            sectionHeader(
                icon: "slider.horizontal.3",
                title: tr("App settings", "Настройки приложения", "Ilova sozlamalari", "Илова созламалари"),
                subtitle: nil
            )
            .padding(.bottom, 8)

            Button {
                IumrahHaptics.soft()
                showLanguageSheet = true
            } label: {
                settingsRow(icon: "globe", title: tr("Language", "Язык", "Til", "Тил"), value: settings.language.title)
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            NavigationLink {
                IumrahAppearanceView()
            } label: {
                settingsRow(
                    icon: "circle.lefthalf.filled",
                    title: tr("Appearance", "Оформление", "Ko‘rinish", "Кўриниш"),
                    value: settings.appearance.title(settings.language)
                )
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            NavigationLink {
                AccountNotificationsView()
            } label: {
                settingsRow(icon: "bell.and.waves.left.and.right.fill", title: tr("Umrah status signal", "Umra статус сигнал", "Umra holat signali", "Умра ҳолат сигнали"), value: signalHistoryValueText)
            }
            .buttonStyle(.plain)

            Divider().padding(.leading, 54)

            Button {
                openSystemSettings()
            } label: {
                settingsRow(
                    icon: "bell.badge.fill",
                    title: tr("Notifications", "Уведомления", "Bildirishnomalar", "Билдиришномалар"),
                    value: notificationStatusText
                )
            }
            .buttonStyle(.plain)
        }
        .iumrahCard()
    }

    private func tripRow(_ session: StoredBookingSession) -> some View {
        HStack(spacing: 12) {
            IumrahIconBadge(
                systemName: tripIcon(session.effectiveStatus),
                role: tripRole(session.effectiveStatus),
                size: 42,
                symbolSize: 16,
                cornerRadius: 14
            )

            VStack(alignment: .leading, spacing: 3) {
                Text("\(session.booking.route.originCode) → \(session.booking.route.outboundDestination)")
                    .font(.subheadline.weight(.bold))
                Text(L10n.format("booking_number_short", settings.language, session.displayBookingNumber) + " · " + L10n.date(session.booking.input.startDate, settings.language))
                    .font(.caption.monospaced().weight(.semibold))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                Text(L10n.status(session.effectiveStatus, settings.language))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            Spacer(minLength: 8)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.bold))
                .foregroundStyle(.tertiary)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 11)
        .contentShape(Rectangle())
    }

    private func sectionHeader(icon: String, title: String, subtitle: String?) -> some View {
        HStack(alignment: .top, spacing: 12) {
            IumrahIconBadge(systemName: icon, size: 40, symbolSize: 16, cornerRadius: 13)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.headline)
                if let subtitle {
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            Spacer(minLength: 0)
        }
    }

    private func accountField(
        _ title: String,
        text: Binding<String>,
        keyboard: UIKeyboardType = .default,
        contentType: UITextContentType? = nil,
        autocapitalization: TextInputAutocapitalization = .words
    ) -> some View {
        TextField(title, text: text)
            .keyboardType(keyboard)
            .textContentType(contentType)
            .textInputAutocapitalization(autocapitalization)
            .autocorrectionDisabled(keyboard == .emailAddress)
            .padding(.horizontal, 16)
            .frame(height: 54)
            .background(Color.iumrahRaisedBackground, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay { RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.7) }
    }

    private func settingsRow(icon: String, title: String, value: String, showsChevron: Bool = true) -> some View {
        HStack(spacing: 12) {
            IumrahIconBadge(systemName: icon, size: 40, symbolSize: 16, cornerRadius: 13)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                Text(value).font(.caption).foregroundStyle(.secondary).lineLimit(2)
            }
            Spacer(minLength: 8)
            if showsChevron {
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(.horizontal, 4)
        .frame(minHeight: 58)
        .contentShape(Rectangle())
    }

    private func tripRole(_ status: String) -> IumrahIconRole {
        IumrahBookingStatusVisual.role(for: status)
    }

    private func statusChip(_ status: String) -> some View {
        Text(L10n.status(status, settings.language))
            .font(.caption2.weight(.bold))
            .foregroundStyle(statusColor(status))
            .padding(.horizontal, 10)
            .frame(height: 30)
            .background(statusColor(status).opacity(0.10), in: Capsule())
            .lineLimit(1)
            .minimumScaleFactor(0.8)
    }

    private func tripDateChip(_ session: StoredBookingSession) -> some View {
        Label(L10n.date(session.booking.input.startDate, settings.language), systemImage: "calendar")
            .font(.caption2.weight(.semibold))
            .foregroundStyle(.secondary)
            .padding(.horizontal, 10)
            .frame(height: 30)
            .background(Color.iumrahRaisedBackground, in: Capsule())
    }

    private var activeTrip: StoredBookingSession? {
        allTrips
            .filter { !["COMPLETED", "CANCELLED"].contains($0.effectiveStatus.uppercased()) }
            .sorted { tripPriority($0) < tripPriority($1) }
            .first
    }

    private var kycTrip: StoredBookingSession? {
        activeTrip ?? allTrips.first
    }

    private var allTrips: [StoredBookingSession] {
        bookings.sessions.sorted { lhs, rhs in
            let l = lhs.booking.input.startDate
            let r = rhs.booking.input.startDate
            if l == r { return lhs.booking.createdAt > rhs.booking.createdAt }
            return l > r
        }
    }

    private var scopedAccountTrips: [StoredBookingSession] {
        allTrips.filter { session in
            let status = session.effectiveStatus.uppercased()
            switch tripScope {
            case .active:
                return !["COMPLETED", "CANCELLED"].contains(status)
            case .past:
                return ["COMPLETED", "CANCELLED"].contains(status)
            }
        }
    }

    private var pendingActivationTrip: StoredBookingSession? {
        bookings.sessions.first { $0.effectiveStatus.uppercased() == "PAYMENT_PENDING" && $0.displayPilgrimID != nil }
    }

    private func tripPriority(_ session: StoredBookingSession) -> String {
        let status = session.effectiveStatus.uppercased()
        let rank: Int
        switch status {
        case "IN_TRIP": rank = 0
        case "READY_TO_TRAVEL": rank = 1
        case "BOOKING_CONFIRMED": rank = 2
        case "PAYMENT_PENDING": rank = 3
        case "AVAILABILITY_CHECK": rank = 4
        default: rank = 9
        }
        return "\(rank)-\(session.booking.input.startDate)"
    }

    private func tripIcon(_ status: String) -> String {
        switch status.uppercased() {
        case "IN_TRIP": return "location.fill"
        case "READY_TO_TRAVEL": return "checkmark.seal.fill"
        case "BOOKING_CONFIRMED": return "checkmark.circle.fill"
        case "PAYMENT_PENDING": return "creditcard.fill"
        case "CANCELLED": return "xmark.circle.fill"
        case "COMPLETED": return "flag.checkered"
        default: return "clock.fill"
        }
    }

    private func statusColor(_ status: String) -> Color {
        IumrahBookingStatusVisual.color(for: status)
    }

    @MainActor
    private func login() async {
        guard !isLoggingIn, guestLoginReady else { return }
        isLoggingIn = true
        loginError = nil
        defer { isLoggingIn = false }
        do {
            if loginEmailChallengeID.isEmpty {
                let response = try await account.startEmailLogin(email: loginEmail.trimmingCharacters(in: .whitespacesAndNewlines).lowercased(), locale: settings.language.rawValue)
                loginEmailChallengeID = response.challengeID
            } else {
                let profile = try await account.confirmEmailLogin(challengeID: loginEmailChallengeID, code: loginEmailCode, locale: settings.language.rawValue)
                await completeAuthenticatedLogin(profile)
                loginEmailChallengeID = ""; loginEmailCode = ""
            }
            IumrahHaptics.success()
        } catch {
            loginError = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func startPhoneLogin() async {
        isLoggingIn = true
        loginError = nil
        defer { isLoggingIn = false }
        do {
            let response = try await account.startPhoneLogin(phone: normalizedUZPhoneInput(loginPhone), locale: settings.language.rawValue)
            loginSMSChallengeID = response.challengeID
            loginSMSCode = ""
            loginPhone = normalizedUZPhoneInput(response.phone)
            IumrahHaptics.success()
        } catch {
            loginError = smartLoginError(error)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func confirmPhoneLogin() async {
        guard !loginSMSChallengeID.isEmpty else { return }
        isLoggingIn = true
        loginError = nil
        defer { isLoggingIn = false }
        do {
            let profile = try await account.confirmPhoneLogin(
                challengeID: loginSMSChallengeID,
                code: loginSMSCode,
                locale: settings.language.rawValue
            )
            await completeAuthenticatedLogin(profile)
            resetPhoneLoginState()
            IumrahHaptics.success()
        } catch {
            loginError = smartLoginError(error)
            IumrahHaptics.error()
        }
    }


    @MainActor
    private func startGuestSMSRegistration() async {
        isRegistering = true
        loginError = nil
        defer { isRegistering = false }
        do {
            let response = try await account.startPhoneRegistration(
                phone: normalizedUZPhoneInput(registrationPhone),
                firstName: registrationFirstName.trimmingCharacters(in: .whitespacesAndNewlines),
                lastName: registrationLastName.trimmingCharacters(in: .whitespacesAndNewlines),
                locale: settings.language.rawValue
            )
            registrationSMSChallengeID = response.challengeID
            registrationSMSCode = ""
            registrationPhone = normalizedUZPhoneInput(response.phone)
            IumrahHaptics.success()
        } catch {
            loginError = smartLoginError(error)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func confirmGuestSMSRegistration() async {
        guard !registrationSMSChallengeID.isEmpty else { return }
        isRegistering = true
        loginError = nil
        defer { isRegistering = false }
        do {
            let profile = try await account.confirmPhoneRegistration(
                challengeID: registrationSMSChallengeID,
                code: registrationSMSCode,
                locale: settings.language.rawValue
            )
            await completeAuthenticatedLogin(profile)
            registrationPassword = ""
            registrationPasswordConfirm = ""
            resetPhoneRegistrationState()
            IumrahHaptics.success()
        } catch {
            loginError = smartLoginError(error)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func startGuestEmailRegistration() async {
        isRegistering = true
        loginError = nil
        registrationEmailIssue = nil
        defer { isRegistering = false }
        do {
            let response = try await IumrahAccountActivationBridge().startEmailRegistration(
                email: registrationEmail.trimmingCharacters(in: .whitespacesAndNewlines).lowercased(),
                locale: settings.language.rawValue
            )
            registrationEmailChallengeID = response.challengeID
            registrationEmailCode = ""
            IumrahHaptics.success()
        } catch {
            if let issue = serverIssueForRegistrationEmail(error) {
                registrationEmailIssue = issue
                loginError = nil
            } else {
                loginError = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
            }
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func confirmGuestEmailRegistration() async {
        guard !registrationEmailChallengeID.isEmpty else { return }
        isRegistering = true
        loginError = nil
        registrationEmailIssue = nil
        defer { isRegistering = false }
        do {
            let response = try await IumrahAccountActivationBridge().confirmEmailRegistration(
                challengeID: registrationEmailChallengeID,
                code: registrationEmailCode,
                firstName: registrationFirstName.trimmingCharacters(in: .whitespacesAndNewlines),
                lastName: registrationLastName.trimmingCharacters(in: .whitespacesAndNewlines),
                locale: settings.language.rawValue
            )
            // Establish the normal app session through IumrahAccountStore so Keychain,
            // push registration and trip restore follow the same path as every login.
            let profile = await account.acceptVerifiedSession(response, locale: settings.language.rawValue)
            await completeAuthenticatedLogin(profile)
            registrationPassword = ""
            registrationPasswordConfirm = ""
            registrationEmailCode = ""
            IumrahHaptics.success()
        } catch {
            loginError = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
            IumrahHaptics.error()
        }
    }

    private func prepareAppleSignIn(_ request: ASAuthorizationAppleIDRequest) {
        do {
            appleNonce = try IumrahAppleSignInSupport.prepare(request)
            isAppleSigningIn = true
            loginError = nil
        } catch {
            loginError = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
        }
    }

    private func completeAppleSignIn(_ result: Result<ASAuthorization, Error>) {
        Task { @MainActor in
            defer { isAppleSigningIn = false }
            do {
                let authorization = try result.get()
                let credential = try IumrahAppleSignInSupport.credential(from: authorization, nonce: appleNonce)
                let profile = try await account.signInWithApple(credential, locale: settings.language.rawValue)
                await completeAuthenticatedLogin(profile)
                IumrahHaptics.success()
            } catch let error as ASAuthorizationError where error.code == .canceled {
                loginError = nil
            } catch {
                loginError = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
                IumrahHaptics.error()
            }
        }
    }

    private func startGoogleSignIn() {
        guard !isGoogleSigningIn, !isAppleSigningIn, !isLoggingIn else { return }
        isGoogleSigningIn = true
        loginError = nil
        Task { @MainActor in
            defer { isGoogleSigningIn = false }
            do {
                let credential = try await IumrahGoogleSignInSupport.signIn()
                let profile = try await account.signInWithGoogle(credential, locale: settings.language.rawValue)
                await completeAuthenticatedLogin(profile)
                IumrahHaptics.success()
            } catch where IumrahGoogleSignInSupport.isCancellation(error) {
                loginError = nil
            } catch {
                loginError = IumrahAccountSecurityCopy.message(for: error, language: settings.language)
                IumrahHaptics.error()
            }
        }
    }

    @MainActor
    private func completeAuthenticatedLogin(_ profile: IumrahAccountProfile) async {
        bookings.setAccountToken(account.bearerToken, owner: account.iumrahID)
        if let token = account.bearerToken {
            await bookings.restoreAccountTrips(token: token)
            await bookings.refreshAll()
        }
        applyProfileToLocalSettings(profile)
        loadProfileDraftIfNeeded(force: true, profile: profile)
        await refreshPublicIdentityLink()
    }

    @MainActor
    private func refreshPublicIdentityLink() async {
        guard account.isAuthenticated, let profile = account.account, let token = account.bearerToken else {
            identityPublicURL = nil
            identityLinkOwner = nil
            identityLinkDate = nil
            return
        }
        if identityLinkOwner == token, let date = identityLinkDate, Date().timeIntervalSince(date) < 60 { return }
        if identityLinkOwner != token { identityPublicURL = nil }
        do {
            let link = try await account.publicIdentityLink()
            guard account.bearerToken == token, !Task.isCancelled else { return }
            identityPublicURL = link.url
            identityLinkOwner = token
            identityLinkDate = Date()
        } catch {
            guard account.bearerToken == token, !Task.isCancelled else { return }
            // The signed link is a convenience layer. Keep the identity card usable even
            // if this endpoint is temporarily unavailable; the fallback page itself does
            // not expose private trip data without a valid signature.
            identityPublicURL = fallbackIdentityURL(profile.iumrahID)
        }
    }

    @MainActor
    private func saveProfile(dismissAfterSave: Bool = false) async {
        isSavingProfile = true
        profileMessage = nil
        defer { isSavingProfile = false }
        do {
            let profile = try await account.updateProfile(
                firstName: firstName.trimmingCharacters(in: .whitespacesAndNewlines),
                lastName: lastName.trimmingCharacters(in: .whitespacesAndNewlines),
                phone: phone.trimmingCharacters(in: .whitespacesAndNewlines),
                email: email.trimmingCharacters(in: .whitespacesAndNewlines),
                telegram: telegram.trimmingCharacters(in: .whitespacesAndNewlines),
                whatsapp: whatsapp.trimmingCharacters(in: .whitespacesAndNewlines)
            )
            applyProfileToLocalSettings(profile)
            profileMessage = savedText
            IumrahHaptics.success()
            if dismissAfterSave { showProfileEditor = false }
        } catch {
            profileMessage = L10n.error(error, settings.language)
            IumrahHaptics.error()
        }
    }

    @MainActor
    private func refreshAccountContent() async {
        balanceRefreshRevision &+= 1
        bookings.setAccountToken(account.bearerToken, owner: account.iumrahID)
        if let token = account.bearerToken {
            await bookings.restoreAccountTrips(token: token)
            await bookings.refreshAll()
        }

        // Revalidate the entire push chain instead of checking only the iOS permission.
        // This catches the common "notifications enabled but nothing arrives" case where
        // APNs has a token but the booking/provider registration is not ready.
        await push.refreshAndRegisterIfAllowed()
        if let deviceToken = push.deviceToken, !deviceToken.isEmpty {
            await bookings.syncPushSubscriptions(deviceToken: deviceToken, locale: settings.language.rawValue)
        }
        await clientNotifications.sync(
            deviceToken: push.deviceToken,
            accountToken: account.bearerToken,
            hasTrip: !bookings.sessions.isEmpty,
            locale: settings.language.rawValue
        )
    }

    @MainActor
    private func loadProfileDraftIfNeeded(force: Bool, profile explicit: IumrahAccountProfile? = nil) {
        guard let profile = explicit ?? account.account else { return }
        if !force, profileLoadedForID == profile.iumrahID { return }
        profileLoadedForID = profile.iumrahID
        firstName = profile.firstName
        lastName = profile.lastName
        phone = profile.phone
        email = profile.email
        telegram = profile.telegram
        whatsapp = profile.whatsapp
    }

    @MainActor
    private func applyProfileToLocalSettings(_ profile: IumrahAccountProfile) {
        settings.firstName = profile.firstName
        settings.lastName = profile.lastName
        settings.phone = profile.phone
        settings.email = profile.email
        settings.telegram = profile.telegram
        settings.whatsapp = profile.whatsapp.isEmpty ? profile.phone : profile.whatsapp
    }

    @MainActor
    private func refreshNotificationStatus() async {
        let value = await UNUserNotificationCenter.current().notificationSettings()
        notificationStatus = value.authorizationStatus
    }

    private func openSystemSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url)
    }

    private var signalHistoryValueText: String {
        let unread = clientNotifications.unreadCount
        if unread > 0 {
            return tr(
                "\(unread) new · full history",
                "\(unread) новых · вся история",
                "\(unread) yangi · to‘liq tarix",
                "\(unread) янги · тўлиқ тарих"
            )
        }
        return tr("Open history", "Открыть историю", "Tarixni ochish", "Тарихни очиш")
    }

    private var notificationStatusText: String {
        switch notificationStatus {
        case .authorized, .provisional, .ephemeral:
            if push.deviceToken == nil {
                return tr("Registering with APNs…", "Регистрация APNs…", "APNs ro‘yxatdan o‘tmoqda…", "APNs рўйхатдан ўтмоқда…")
            }
            if bookings.pushRegistrationError != nil || clientNotifications.lastError != nil {
                return tr("Delivery connection error", "Ошибка подключения доставки", "Yetkazish ulanishida xato", "Етказиш уланишида хато")
            }
            if bookings.pushRegistrationReady == false || clientNotifications.pushProviderReady == false {
                return tr("Push service is not ready", "Push-сервис не готов", "Push xizmati tayyor emas", "Push хизмати тайёр эмас")
            }
            return tr("Enabled · test delivery in Signal", "Включены · проверка доставки в Signal", "Yoqilgan · Signalda tekshiring", "Ёқилган · Signalда текширинг")
        case .denied:
            return tr("Disabled in iOS Settings", "Выключены в настройках iOS", "iOS sozlamalarida o‘chirilgan", "iOS созламаларида ўчирилган")
        default:
            return tr("Not configured", "Не настроены", "Sozlanmagan", "Созланмаган")
        }
    }

    private var savedText: String { tr("Saved", "Сохранено", "Saqlandi", "Сақланди") }

    private func displayName(_ profile: IumrahAccountProfile) -> String {
        let value = profile.displayName.trimmingCharacters(in: .whitespacesAndNewlines)
        if !value.isEmpty { return value }
        let fallback = [profile.firstName, profile.lastName].filter { !$0.isEmpty }.joined(separator: " ")
        return fallback.isEmpty ? tr("Pilgrim", "Паломник", "Ziyoratchi", "Зиёратчи") : fallback
    }

    private func normalizedID(_ value: String) -> String {
        let digits = value.filter(\.isNumber)
        guard !digits.isEmpty else { return value }
        if digits.count >= 8 { return digits }
        return String(repeating: "0", count: 8 - digits.count) + digits
    }

    private func nonBlank(_ value: String?) -> String? {
        guard let value else { return nil }
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    private func normalizedUZPhoneInput(_ raw: String) -> String {
        let digits = String(raw.filter(\.isNumber).prefix(12))
        return digits.isEmpty ? "" : "+" + digits
    }

    private func normalizedLoginIdentifier(_ value: String) -> String {
        let digits = value.filter(\.isNumber)
        guard digits.count == 6 || digits.count == 8 else { return value }
        return normalizedID(digits)
    }

    @ViewBuilder
    private func fieldIssueView(_ issue: IumrahFieldIssue) -> some View {
        Text(issue.message)
            .font(.footnote.weight(.semibold))
            .foregroundStyle(issue.tone.color)
            .frame(maxWidth: .infinity, alignment: .leading)
            .fixedSize(horizontal: false, vertical: true)
    }

    private var loginEmailFieldIssue: IumrahFieldIssue? {
        if let loginEmailServerIssue { return loginEmailServerIssue }
        return emailFieldIssue(for: loginEmail)
    }

    private var registrationEmailFieldIssue: IumrahFieldIssue? {
        if let registrationEmailIssue { return registrationEmailIssue }
        return emailFieldIssue(for: registrationEmail)
    }

    private func emailFieldIssue(for raw: String) -> IumrahFieldIssue? {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !value.isEmpty else { return nil }
        if value.contains(" ") {
            return IumrahFieldIssue(
                message: tr(
                    "Email must not contain spaces.",
                    "Email не должен содержать пробелы.",
                    "Email ichida bo‘sh joy bo‘lmasligi kerak.",
                    "Email ичида бўш жой бўлмаслиги керак."
                ),
                tone: .error
            )
        }
        if !value.contains("@") {
            return IumrahFieldIssue(
                message: tr(
                    "Add @ to the email address.",
                    "Добавьте @ в адрес email.",
                    "Email manziliga @ qo‘shing.",
                    "Email манзилига @ қўшинг."
                ),
                tone: .warning
            )
        }
        let parts = value.split(separator: "@", omittingEmptySubsequences: false)
        if parts.count != 2 || parts[0].isEmpty || parts[1].isEmpty {
            return IumrahFieldIssue(
                message: tr(
                    "Check the email format.",
                    "Проверьте формат email.",
                    "Email formatini tekshiring.",
                    "Email форматини текширинг."
                ),
                tone: .error
            )
        }
        if !parts[1].contains(".") {
            return IumrahFieldIssue(
                message: tr(
                    "Add a domain such as .com or .uz.",
                    "Добавьте домен, например .com или .uz.",
                    "Masalan .com yoki .uz domenini qo‘shing.",
                    "Масалан .com ёки .uz доменини қўшинг."
                ),
                tone: .warning
            )
        }
        let domainPieces = parts[1].split(separator: ".")
        if domainPieces.last?.count ?? 0 < 2 {
            return IumrahFieldIssue(
                message: tr(
                    "The email domain looks incomplete.",
                    "Домен email выглядит неполным.",
                    "Email domeni to‘liq emasga o‘xshaydi.",
                    "Email домени тўлиқ эмасга ўхшайди."
                ),
                tone: .error
            )
        }
        return nil
    }

    private func smartLoginError(_ error: Error) -> String {
        if case APIError.server(_, let message) = error {
            let code = message.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
            switch code {
            case "INVALID_CREDENTIALS":
                if guestAuthMethod == .sms {
                    return tr(
                        "We could not verify this phone sign-in. Check the number or code and try again.",
                        "Не удалось подтвердить вход по телефону. Проверьте номер или код и попробуйте снова.",
                        "Telefon orqali kirishni tasdiqlab bo‘lmadi. Raqam yoki kodni tekshirib, qayta urinib ko‘ring.",
                        "Телефон орқали киришни тасдиқлаб бўлмади. Рақам ёки кодни текшириб, қайта уриниб кўринг."
                    )
                }
                return tr(
                    "The account was not found or the password is incorrect.",
                    "Аккаунт не найден или пароль введён неверно.",
                    "Akkaunt topilmadi yoki parol noto‘g‘ri kiritildi.",
                    "Аккаунт топилмади ёки парол нотўғри киритилди."
                )
            case "VERIFICATION_CODE_INVALID":
                return tr(
                    "The SMS code is incorrect or has expired.",
                    "SMS-код неверный или уже истёк.",
                    "SMS kod noto‘g‘ri yoki muddati tugagan.",
                    "SMS код нотўғри ёки муддати тугаган."
                )
            case "PHONE_INVALID":
                return tr(
                    "Enter a valid Uzbekistan phone number.",
                    "Введите корректный номер Узбекистана.",
                    "To‘g‘ri O‘zbekiston telefon raqamini kiriting.",
                    "Тўғри Ўзбекистон телефон рақамини киритинг."
                )
            case "SMS_RATE_LIMITED":
                return tr(
                    "Too many SMS attempts. Please wait a little and try again.",
                    "Слишком много попыток по SMS. Подождите немного и попробуйте снова.",
                    "SMS urinishlari juda ko‘p bo‘ldi. Biroz kutib, yana urinib ko‘ring.",
                    "SMS уринишлари жуда кўп бўлди. Бироз кутиб, яна уриниб кўринг."
                )
            case "PHONE_ACCOUNT_NOT_FOUND":
                return tr(
                    "No iumrah account is linked to this phone yet. Switch to Register to create one.",
                    "К этому номеру пока не привязан аккаунт iumrah. Переключитесь на «Регистрация», чтобы создать его.",
                    "Bu raqamga hali iumrah akkaunti ulanmagan. Akkaunt yaratish uchun Ro‘yxatdan o‘tishga o‘ting.",
                    "Бу рақамга ҳали iumrah аккаунти уланмаган. Аккаунт яратиш учун Рўйхатдан ўтишга ўтинг."
                )
            case "PHONE_ALREADY_CONNECTED", "ACCOUNT_ALREADY_ACTIVE":
                return tr(
                    "This phone already belongs to an iumrah account. Switch to Sign in and use the SMS code.",
                    "Этот номер уже привязан к аккаунту iumrah. Переключитесь на «Вход» и войдите по SMS-коду.",
                    "Bu raqam allaqachon iumrah akkauntiga ulangan. Kirish bo‘limiga o‘tib SMS kodi bilan kiring.",
                    "Бу рақам аллақачон iumrah аккаунтига уланган. Кириш бўлимига ўтиб SMS коди билан киринг."
                )
            case "SMS_DELIVERY_NOT_CONFIGURED", "SMS_DELIVERY_UNAVAILABLE":
                return tr(
                    "The SMS service could not send the code right now. Please try again shortly.",
                    "Сейчас SMS-сервис не смог отправить код. Попробуйте ещё раз через некоторое время.",
                    "SMS xizmati hozir kodni yubora olmadi. Birozdan so‘ng yana urinib ko‘ring.",
                    "SMS хизмати ҳозир кодни юбора олмади. Бироздан сўнг яна уриниб кўринг."
                )
            case "PASSWORD_TOO_WEAK":
                return tr(
                    "Create a password with at least 8 characters.",
                    "Создайте пароль минимум из 8 символов.",
                    "Kamida 8 ta belgidan iborat parol yarating.",
                    "Камида 8 та белгидан иборат парол яратинг."
                )
            default:
                break
            }
        }
        return IumrahAccountSecurityCopy.message(for: error, language: settings.language)
    }

    private func serverIssueForEmailLogin(_ error: Error) -> IumrahFieldIssue? {
        guard case APIError.server(_, let message) = error else { return nil }
        let code = message.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        switch code {
        case "INVALID_CREDENTIALS":
            return IumrahFieldIssue(
                message: tr(
                    "We couldn’t sign you in. Check the email and password.",
                    "Не удалось войти. Проверьте email и пароль.",
                    "Kirish amalga oshmadi. Email va parolni tekshiring.",
                    "Кириш амалга ошмади. Email ва паролни текширинг."
                ),
                tone: .error
            )
        case "EMAIL_INVALID":
            return IumrahFieldIssue(
                message: tr(
                    "This email address looks invalid.",
                    "Этот email-адрес выглядит некорректным.",
                    "Bu email manzili noto‘g‘ri ko‘rinmoqda.",
                    "Бу email манзили нотўғри кўринмоқда."
                ),
                tone: .error
            )
        default:
            return nil
        }
    }

    private func serverIssueForRegistrationEmail(_ error: Error) -> IumrahFieldIssue? {
        guard case APIError.server(_, let message) = error else { return nil }
        let code = message.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        switch code {
        case "EMAIL_INVALID":
            return IumrahFieldIssue(
                message: tr(
                    "Enter a real email address to continue.",
                    "Введите реальный email-адрес, чтобы продолжить.",
                    "Davom etish uchun haqiqiy email manzilini kiriting.",
                    "Давом этиш учун ҳақиқий email манзилини киритинг."
                ),
                tone: .error
            )
        case "EMAIL_ALREADY_CONNECTED":
            return IumrahFieldIssue(
                message: tr(
                    "This email is already linked to another iumrah account.",
                    "Этот email уже привязан к другому аккаунту iumrah.",
                    "Bu email allaqachon boshqa iumrah akkauntiga ulangan.",
                    "Бу email аллақачон бошқа iumrah аккаунтига уланган."
                ),
                tone: .error
            )
        default:
            return nil
        }
    }

    private func resetPhoneLoginState() {
        loginSMSChallengeID = ""
        loginSMSCode = ""
    }


    private func resetPhoneRegistrationState() {
        registrationSMSChallengeID = ""
        registrationSMSCode = ""
    }

    private func copyIdentityID(_ profile: IumrahAccountProfile) {
        let message = tr("iumrah ID copied.", "iumrah ID скопирован.", "iumrah ID nusxalandi.", "iumrah ID нусхаланди.")
        UIPasteboard.general.string = normalizedID(profile.iumrahID)
        identityCopyMessage = message
        IumrahHaptics.success()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
            if identityCopyMessage == message {
                identityCopyMessage = nil
            }
        }
    }

    private func fallbackIdentityURL(_ value: String) -> String {
        "https://iumrah.app/id/\(normalizedID(value))"
    }

    private func prepareIdentityRevealIfNeeded(_ rawID: String?, force: Bool = false) {
        guard let rawID, !rawID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            identityRevealProgress = 0
            return
        }

        let id = normalizedID(rawID)
        let key = "iumrah.identity-card.revealed.\(id)"
        if !force, UserDefaults.standard.bool(forKey: key) {
            identityRevealProgress = 1
            return
        }

        identityCardFlipped = false
        identityRevealProgress = 0

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            withAnimation(.easeInOut(duration: 1.45)) {
                identityRevealProgress = 1
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.72) {
                IumrahHaptics.success()
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.55) {
                UserDefaults.standard.set(true, forKey: key)
            }
        }
    }

    @MainActor
    private func addIdentityToWallet() async {
        guard !isLoadingWalletPass else { return }
        guard PKPassLibrary.isPassLibraryAvailable() else {
            walletAlertMessage = tr(
                "Apple Wallet is not available on this device.",
                "Apple Wallet недоступен на этом устройстве.",
                "Apple Wallet bu qurilmada mavjud emas.",
                "Apple Wallet бу қурилмада мавжуд эмас."
            )
            return
        }

        isLoadingWalletPass = true
        defer { isLoadingWalletPass = false }

        do {
            let data = try await account.walletPassData()
            let pass = try PKPass(data: data)
            walletPass = pass
            showWalletPassSheet = true
            IumrahHaptics.soft()
        } catch {
            walletAlertMessage = walletErrorText(error)
            IumrahHaptics.error()
        }
    }

    private func walletErrorText(_ error: Error) -> String {
        if case APIError.server(_, let message) = error,
           message == "WALLET_PASS_NOT_CONFIGURED" {
            return tr(
                "iumrah ID for Apple Wallet is being activated on the server. Please try again later.",
                "iumrah ID для Apple Wallet ещё активируется на сервере. Попробуйте немного позже.",
                "Apple Wallet uchun iumrah ID serverda faollashtirilmoqda. Birozdan keyin qayta urinib ko‘ring.",
                "Apple Wallet учун iumrah ID серверда фаоллаштирилмоқда. Бироздан кейин қайта уриниб кўринг."
            )
        }
        return tr(
            "We could not prepare the Wallet pass right now. Please try again.",
            "Сейчас не удалось подготовить карту для Wallet. Попробуйте ещё раз.",
            "Hozir Wallet kartasini tayyorlab bo‘lmadi. Qayta urinib ko‘ring.",
            "Ҳозир Wallet картасини тайёрлаб бўлмади. Қайта уриниб кўринг."
        )
    }

    private func tr(_ en: String, _ ru: String, _ uz: String, _ cyrl: String) -> String {
        switch settings.language {
        case .russian: return ru
        case .english, .turkish, .indonesian, .malay, .arabic: return en
        case .uzbek: return uz
        case .uzbekCyrillic: return cyrl
        }
    }
}
