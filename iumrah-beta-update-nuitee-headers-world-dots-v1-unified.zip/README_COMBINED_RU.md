# iumrah — объединённый патч: Nuitee Hotels V1 + заголовки + World of Dots

Дата: 26.10.2026. База: `kepler-ios-main 4.zip`.
Это ОДИН ZIP-патч. Два предыдущих патча по отдельности устанавливать НЕ нужно.
Все пути внутри архива относятся к КОРНЮ исходного репозитория.

## Что объединено

1. Новый чёрно-белый фирменный стиль основных вкладок, общие заголовки,
   нижняя навигация и анимированная карта мира (SwiftUI + Metal). Заголовок
   страницы отелей и три внутренних переключателя — на одном фоне.
2. Nuitee Hotels V1 В СУЩЕСТВУЮЩЕМ разделе «Отели»: Мекка/Медина, фильтр
   по звёздам 1–5, список отелей; стандартный заезд через 10 дней,
   1 ночь, 1 номер, 2 взрослых. Стоимость в карточке — за НОМЕР,
   не за весь умра-пакет.
3. Страница отеля: фото/галерея, описание, удобства, номера и тарифы
   по датам, индивидуальные условия отмены тарифа, где возвращает Nuitee.
4. Cloudflare Package Engine: серверные маршруты `/api/package/nuitee/*`,
   D1-кеш ориентировочных цен 48 часов и тарифов конкретного отеля 10 минут.
5. Старая гостиничная выдача из собственной базы отключена ТОЛЬКО во вкладке
   «Отели», но её код и данные оставлены для уже существующих сценариев.
   Авиабилеты и Sunday Club остаются на прежних источниках.

## Установка

1. Загрузить ТОЛЬКО ЭТОТ файл `iumrah-beta-update-*.zip` в корень
   репозитория. Имеющийся `.github/workflows/apply-beta-update.yml`
   распознаёт такой шаблон имени и распаковывает файлы.
2. В Nuitee Connect > API Keys взять тестовый ключ `sand_...` для
   разработки или Production API Key для настоящих цен (после активации).
3. GitHub > репозиторий > Settings > Secrets and variables > Actions >
   New repository secret:
      Name: `NUITEE_API_KEY`
      Secret: точное значение ключа Nuitee (БЕЗ кавычек).
   Ключ НЕ добавлять в код Swift, project.yml, wrangler.template.jsonc,
   GitHub Variables или любой ZIP.
4. После применения архива: Actions > Deploy iumrah Package Engine >
   Run workflow. Скрипт применит D1-миграцию, развернёт Worker
   `iumrah-package-api` и перенесёт `NUITEE_API_KEY` из GitHub Secrets
   в защищённые Cloudflare Worker Secrets.
5. Затем выполнить `xcodegen generate`, собрать приложение через
   существующий TestFlight workflow и проверить iPhone 11/13 mini.

## Какие ещё секреты нужны

Для нового Nuitee API нужен ТОЛЬКО `NUITEE_API_KEY`.
В существующем Deploy Package Engine уже используются:
`CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_ZONE_ID`,
`IGNAV_API_KEY`, `TRAVELPAYOUTS_API_TOKEN`, `DEVSMS_API_TOKEN`,
`WALLET_CERT_PEM`, `WALLET_KEY_PEM`. Workflow проверяет их наличие и может
прервать деплой, если существующие секреты не настроены.
Новый D1 создавать не нужно: workflow использует существующую базу
`iumrah-hotels` и добавляет таблицу кеша.

Альтернативный путь: Cloudflare > Workers & Pages > `iumrah-package-api` >
Settings > Variables and Secrets > Add > Secret. Создать `NUITEE_API_KEY`
на стороне Cloudflare. При GitHub-пути настраивать его второй раз вручную
не нужно. После изменения GitHub Secret перезапустите Deploy workflow,
иначе активный Cloudflare Worker продолжит использовать прежнее значение.

## Ограничения

- Текущий `sand_`-ключ возвращает ТЕСТОВЫЕ тарифы, не реальные цены.
- Выбор Nuitee-номера ещё не включён в окончательный серверный расчёт
  умра-пакета. Реальное бронирование в iumrah Business не сделано.
- Flights API Nuitee НЕ интегрирован: существующие Flights не изменены.
- Настоящая сборка Xcode/компиляция Metal, Cloudflare Deploy и реальные
  запросы Nuitee в рамках создания патча не выполнялись.
