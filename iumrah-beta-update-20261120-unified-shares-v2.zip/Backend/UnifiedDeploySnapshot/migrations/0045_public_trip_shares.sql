-- Additive, backward-compatible D1 schema for IUMRAH public share links.
-- Store only SHA-256 of the random viewer token, never personal documents.
CREATE TABLE IF NOT EXISTS booking_public_shares (
    token_hash TEXT PRIMARY KEY NOT NULL,
    booking_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    revoked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_booking_public_shares_booking
  ON booking_public_shares (booking_id);
